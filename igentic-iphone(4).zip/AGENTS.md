# Agent Instructions

This repository is an experimental privacy-first iPhone AI Runtime Layer skeleton.

It is a working repository, not a static concept archive. Treat `main` as the stable public branch, use small task branches, and keep privacy/security rules ahead of autonomy.

## Repository identity

- Expected repository name: `igentic-iphone`
- Expected default branch: `main`
- Expected initial visibility: public
- Fresh repo only. Do not mix this project into the Pokekartenkiste repo or any older project.

## Required pre-read for ChatGPT and coding agents

1. `PROJECT_STATE.md`
2. `README.md`
3. `AGENTS.md`
4. `CONTRIBUTING.md`
5. `docs/WORKFLOW.md`
6. `docs/CHATGPT_NEXT_TASK.md`
7. `docs/CODEX_NEXT_TASK.md`
8. `docs/ASSUMPTIONS.md`
9. `docs/privacy-model.md`

## Hard rules

- Privacy before autonomy.
- No secrets, API keys, provisioning profiles, model weights, or personal data.
- No external model calls without a policy check, data minimization, audit log design, and explicit user approval.
- No critical action without user confirmation.
- No broad device automation through unsafe UI scripting.
- No background agent behavior that runs without user awareness.
- No private Apple APIs.
- No model runtime dependency unless license, platform support, footprint, and security impact are documented.
- Keep English file names, code comments, API names, and branch names.
- User-facing docs may be German or English.

## ChatGPT operating model

ChatGPT manages product strategy, architecture consistency, task slicing, and PR review.

Before preparing a Codex task, ChatGPT must:

1. Read the current GitHub repo state.
2. Read `PROJECT_STATE.md` and `docs/CHATGPT_NEXT_TASK.md`.
3. Update `docs/CODEX_NEXT_TASK.md` if implementation is needed.
4. Provide only a short copy-paste prompt for Codex.

After Codex creates a draft PR, ChatGPT must independently review:

- base branch and working branch
- actual diff and changed files
- tests and validation output
- privacy/security impact
- whether the PR stayed inside `docs/CODEX_NEXT_TASK.md`

ChatGPT must not claim a PR exists unless the real GitHub PR exists.

## Codex / coding-agent operating model

Codex should use the task in `docs/CODEX_NEXT_TASK.md` as the single source of truth.

Required first checks in a connected repo workspace:

```bash
git remote -v
git status --branch --short
git branch --show-current
```

Stop if the checkout is not connected to the expected GitHub repository.

Required validation before reporting:

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Use a branch named `codex/<task-name>` and create a draft PR into `main` when code or docs change.

## Credit-saving task design

- One narrow task at a time.
- Prefer AgentCore-only, docs-only, or tests-only slices.
- Do not ask Codex to research broad platform strategy.
- Do not provide unnecessary files in the prompt.
- Keep model runtime experiments separate from policy/kernel changes.
- Prefer deterministic Swift tests before adding device-only integrations.

## Stop rules

Stop and ask for review if a change would:

- send user data to an external service
- add secrets or credentials
- weaken approval requirements
- add background behavior that could run without user awareness
- introduce a new model runtime with unclear license terms
- require Xcode/iOS versions not documented in `docs/ASSUMPTIONS.md`
- add generated build artifacts or large binary files
