# Contributing

This repository is intentionally structured so it can be edited by humans, ChatGPT, Codex, and future coding agents without losing the privacy-first architecture.

## Working rules

- Keep changes small, reviewable, and tied to one task.
- Privacy, policy, approval, and auditability come before autonomy.
- Add or update tests when changing `ios/Sources/AgentCore`.
- Do not add secrets, provisioning profiles, model weights, personal data, or generated build artifacts.
- Do not introduce external AI calls without updating `PRIVACY.md`, `DELEGATION.md`, and policy tests.
- Prefer safe skeletons and documented extension points over large hidden behavior.

## Local validation

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Or from the repository root:

```bash
npm run check
```

`bun run check` should also work because the scripts do not require npm-specific packages.

## Branch naming

Use focused branches:

- `chatgpt/<short-task>` for ChatGPT-authored repo-maintenance changes.
- `codex/<short-task>` for Codex implementation tasks.
- `docs/<short-topic>` for documentation-only branches.
- `spike/<short-topic>` for throwaway research prototypes.

## Pull requests

Every PR should include:

- scope
- changed files
- tests run
- privacy/security impact
- open questions

A PR that adds capability without policy coverage should stay draft.


## Open source contribution rules

By submitting a contribution, you agree that it is licensed under Apache-2.0, unless explicitly marked otherwise. Keep pull requests small, disclose material AI assistance when relevant, and do not add telemetry, external delegation, or sensitive data handling without privacy and security review.



## First-time contributor path

Good first contributions should not require model downloads, Apple Developer account access, private user data, or device-only APIs.

Recommended starter areas:

- improve docs clarity
- add tests for existing AgentCore behavior
- add model/runtime evaluation notes without dependencies
- expand threat-model examples
- improve issue templates

## Required checks

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

A PR that changes privacy, delegation, action execution, or audit behavior needs explicit security/privacy review.
