# Project State

## Project

- Name: iGentic iPhone
- Repository name: `igentic-iphone`
- Goal: privacy-first iPhone AI Runtime Layer / Personal AI Compute Layer
- Primary target device assumption: iPhone Air
- Status: Experimental / Research Prototype
- License: Apache-2.0
- Intended visibility: public from first import

## Current repo contents

- Swift Package skeleton under `ios/`
- `AgentCore` policy/routing/approval/audit skeleton
- `AgentIntents` bridge skeleton, intentionally not a production App Intents implementation yet
- `AgentUI` lightweight view skeleton
- Architecture and privacy documentation
- Open-source community files
- ChatGPT/Codex workflow files
- Validator script for repository shape and safety checks

## Current validation commands

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Root convenience command:

```bash
npm run check
# or
bun run check
```

## Current architectural decision

Start with a deterministic AgentCore kernel before integrating Apple device-only frameworks or local model runtimes.

Reason: this keeps the first repo testable on normal Swift toolchains and avoids prematurely depending on Xcode provisioning, model downloads, private data access, or unstable runtime assumptions.

## Current next ChatGPT action

After the ZIP is pushed to GitHub:

1. Verify the real repo is a fresh `igentic-iphone` repo.
2. Read `PROJECT_STATE.md`, `AGENTS.md`, `docs/WORKFLOW.md`, `docs/CHATGPT_NEXT_TASK.md`, and `docs/CODEX_NEXT_TASK.md`.
3. Prepare the first narrow Codex task only if the repo import is clean.

## Current next Codex action

Run the import verification task in `docs/CODEX_NEXT_TASK.md`.

## Non-goals for the first public commit

- No production iOS app target yet.
- No model weights.
- No external API calls.
- No cloud account setup.
- No App Store configuration.
- No always-on background agent.
- No sensitive personal-data ingestion.

## Merge gate

A PR should not merge unless:

- validator passes
- Swift tests pass or the limitation is documented
- no secrets or build artifacts are added
- privacy model is not weakened
- changed files match the task scope
- `PROJECT_STATE.md` or next-task docs are updated if the repo state changes
