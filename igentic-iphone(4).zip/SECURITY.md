# Security Policy

## Status

iGentic iPhone is an experimental research prototype. It is not production software and must not be used as a trusted autonomous agent for medical, legal, financial, identity, payment, or safety-critical decisions.

## Reporting security issues

Please do not disclose exploitable vulnerabilities publicly before maintainers have had time to review them.

For now, report privately to the repository owner/maintainers through GitHub's private vulnerability reporting if enabled. If private reporting is not enabled yet, open a minimal public issue titled `Security contact needed` without exploit details.

## Security review scope

High-priority issues include:

- data exfiltration paths
- unsafe external model delegation
- missing approval gates for critical actions
- secrets committed to the repository
- local storage or audit log privacy leaks
- insecure worker/delegation protocols
- unsafe App Intents or Shortcuts behavior

## Security baseline

Every feature must define:

1. data class
2. allowed runtime mode
3. required approval level
4. audit event
5. delegation restrictions
6. rollback or user-visible failure mode
