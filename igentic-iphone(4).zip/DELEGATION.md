# Delegation Layer

## Core idea

The iPhone is the **Trust & Control Plane**. Other devices are **Compute Plane**.

The iPhone decides:

- whether delegation is needed
- what data class is involved
- what context can leave the device
- which destination is allowed
- whether user approval is required
- whether the returned result is safe to act on

## Delegation targets

| Target | Use cases | Privacy posture |
| --- | --- | --- |
| Local iPhone | routing, short summaries, local RAG, drafts | best default |
| Mac | larger LLMs, coding agent, long documents, media processing | trusted device |
| Home Server | always-on queue, private index, automations | trusted device, needs hardening |
| Private Cloud Compute | Apple-managed larger model execution | optional, policy-gated |
| External AI | ChatGPT, Claude, Gemini, other APIs | explicit task-level approval |

## Privacy Broker flow

1. Analyze task.
2. Determine data class.
3. Minimize private raw data.
4. Redact PII when possible.
5. Select target system.
6. Check user approval requirement.
7. Send job.
8. Receive result.
9. Verify result locally.
10. Execute only after approval if critical.
11. Write audit log.

## Trusted device protocol sketch

A future trusted-device worker should support:

- device pairing
- mutual authentication
- encrypted transport
- job queue
- result signatures
- cancellation
- policy metadata
- no silent persistence of raw private payloads

Potential technologies:

- Network Framework
- Multipeer Connectivity
- local HTTPS
- MCP Swift SDK
- custom protobuf or JSON protocol

## External AI policy

External AI is not a default mode. It must be explicit, visible and auditable.

Required controls:

- show outgoing context preview
- redact/minimize before send
- include provider name
- show estimated sensitivity
- require approval for Level 3+
- deny automatic Level 4 delegation
