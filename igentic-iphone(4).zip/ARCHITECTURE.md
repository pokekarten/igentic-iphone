# Architecture

## Product framing

iGentic iPhone is a privacy-first iPhone AI runtime layer. It treats the iPhone as a **trust and control plane** for personal AI: identity, context, permissions, approvals, audit logs and private local state remain close to the user.

The architecture separates:

- **Trust plane:** iPhone Air, Keychain, local policy, approvals, data classification, audit.
- **Execution plane:** local models, App Intents, Shortcuts, local APIs.
- **Compute plane:** Mac, home server, Private Cloud Compute, external AI providers.

## Core flow

```text
Input Surface
  Siri / Shortcut / Widget / App / Share Sheet
      ↓
AgentKernel
      ↓
TaskRouter ── CapabilityRegistry
      ↓
PolicyEngine ── DataClassification ── PrivacyBroker
      ↓
LocalModelRuntime / ToolRegistry / DelegationBroker
      ↓
ApprovalManager
      ↓
AppIntentBridge / local API / trusted worker / external adapter
      ↓
AuditLog + ResultVerification
```

## Kernel modules

### AgentKernel

Coordinates the request lifecycle. It does not own every capability. It orchestrates routing, policy checks, approvals, execution and audit logging.

### TaskRouter

Maps a user request to a task intent and an execution strategy. The first implementation is rule-based and deterministic. Later versions can use a small local model as an intent classifier.

### PolicyEngine

Decides whether an operation is allowed, requires approval, must stay local or is denied.

### LocalModelRuntime

Abstracts local model execution. The skeleton only returns deterministic placeholder output. Runtime adapters can later target Apple Foundation Models, Core AI, MLX Swift, MLC-LLM or llama.cpp-derived runtimes.

### ToolRegistry

Registers safe tools. Tools expose typed capabilities; they do not freely click UI.

### AppIntentBridge

Future bridge for App Intents and Shortcuts. It should map approved actions to first-party or app-owned capabilities.

### PrivacyBroker

Prepares data for delegation by minimizing, redacting and summarizing context before it leaves the device.

### DelegationBroker

Selects trusted or external compute targets, then sends only policy-approved payloads.

### ApprovalManager

Controls human-in-the-loop confirmation. Critical actions require approval.

### AuditLog

Records policy-relevant decisions with redaction.

### CapabilityRegistry

Future inventory of local and delegated capabilities, including cost, latency, privacy posture, availability and required permissions.

## Execution model

The agent loop should remain bounded:

1. Receive user request.
2. Understand intent.
3. Determine required data.
4. Classify data.
5. Select local model or tool.
6. Build a short plan.
7. Ask clarifying question only when necessary.
8. Execute local tool or prepare action.
9. Request approval for critical action.
10. Verify result.
11. Write audit log.
12. Return answer.

## Non-goals

- No unrestricted UI automation.
- No silent external data sharing.
- No always-on background agent claim.
- No production-grade secure storage implementation in this starter.
- No claim that current Apple APIs expose every Apple Intelligence capability to third-party apps.
