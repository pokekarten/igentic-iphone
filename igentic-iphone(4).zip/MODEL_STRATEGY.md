# Model Strategy

## Design stance

Use a hybrid model stack. Apple-native intelligence is the best system integration layer. A free local model is the best controllable agent brain. A small router model reduces cost and heat. Larger models are optional delegated compute.

## Candidate model roles

| Model / layer | Role | Strength | Risk / limit | Status |
| --- | --- | --- | --- | --- |
| Apple Foundation Models | Native iPhone intelligence | Swift-native, Apple ecosystem, Apple Intelligence-adjacent workflows | less controllable than self-hosted model; availability depends on OS/API/region | Evaluate first for native tasks |
| Core AI / Core ML | On-device model integration | device-local execution, Apple silicon optimization | model conversion and OS requirements may move quickly | Evaluate as runtime layer |
| Qwen3-4B | Local agent brain | strong controllable open candidate, tool-use relevant, multilingual | needs quantization and runtime benchmarking on iPhone Air | Primary free model candidate |
| Qwen3-1.7B or similar | Router / intent classifier | fast local classification and prefiltering | less capable for complex planning | Candidate for routing |
| Llama 3.2 1B / 3B | Mobile/edge model | strong edge positioning | license and runtime fit must be checked | Compare |
| Gemma 3 small variants | Mobile/edge tests | useful baseline candidates | license/runtime details must be checked | Compare |
| Phi-4-mini | Structured tasks / reasoning | compact 3.8B-class model | benchmark on target hardware before adopting | Compare |
| Embedding model | Local memory and RAG | private search and retrieval | storage and index encryption needed | Required for Phase 4 |

## iPhone Air sizing assumptions

- 1B: comfortable for routing and lightweight tasks.
- 3B: likely sweet spot for local utility.
- 4B: realistic when quantized and used for bounded sessions.
- 7B/8B: possible in some runtimes but likely not ideal for sustained use.
- Larger: delegate.

These are planning assumptions, not performance claims. The repository includes no benchmark results yet.

## Runtime candidates

### Apple Foundation Models

Use for native system-adjacent tasks, Apple-integrated text understanding, summarization and future App Intents workflows.

### Core AI / Core ML

Use for on-device model packaging and Apple silicon execution. Core AI is especially relevant for future on-device generative model experiments if the deployment target and tooling requirements are acceptable.

### MLX Swift / MLX

Use for Apple-silicon-first experimentation, especially on Mac and potentially iOS where supported.

### MLC-LLM

Candidate for deployment-oriented LLM execution across platforms.

### llama.cpp / GGUF-derived runtimes

Important baseline for quantized local models and community model support.

## Model selection policy

1. Prefer local deterministic code for simple classification.
2. Use small router model for ambiguous intents.
3. Use 3B/4B local model for private summaries, planning and tool selection.
4. Use trusted device worker for long documents, codebases or large contexts.
5. Use external AI only after policy check, data minimization and explicit approval.


## Current implementation guardrail

Do not add a real model runtime dependency in the first feature slice. The first implementation target is deterministic AgentCore policy/routing/approval/audit logic.

Core AI, MLX Swift, MLC-LLM, llama.cpp-derived runtimes, and Qwen variants are evaluation tracks. Each runtime needs a separate issue/PR covering:

- target OS and Xcode requirements
- license compatibility
- model file size and storage behavior
- memory footprint
- thermal/battery behavior on iPhone Air
- offline behavior
- privacy and audit implications

No model weights should be committed to this repository.
