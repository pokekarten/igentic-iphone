# Code of Conduct

## Our pledge

We want iGentic iPhone to be a respectful, practical, and privacy-conscious open-source research project. Everyone is welcome to contribute regardless of background, experience level, identity, location, or native language.

## Expected behavior

- Be respectful and constructive.
- Assume good intent, but accept corrections quickly.
- Discuss technical trade-offs with evidence.
- Keep privacy and safety concerns visible.
- Help newcomers find small, useful contribution paths.

## Unacceptable behavior

- Harassment, insults, threats, or discrimination.
- Publishing private information without consent.
- Pressuring maintainers to merge unsafe privacy/security changes.
- Introducing telemetry, data export, or external AI delegation without clear policy and review.

## Enforcement

Maintainers may edit, hide, close, or lock discussions that violate this code. Serious or repeated violations may lead to blocked participation. Security-sensitive reports should follow `SECURITY.md` rather than public issue threads.
