---
name: Feature request
description: Propose a new capability for iGentic iPhone
title: "Feature: "
labels: ["feature"]
---

## Goal

What user problem does this solve?

## Privacy impact

Which data classes are involved?

- [ ] Level 0: Public
- [ ] Level 1: Low-risk app data
- [ ] Level 2: Personal task context
- [ ] Level 3: Sensitive personal context
- [ ] Level 4: Highly sensitive

## Action type

- [ ] Read
- [ ] Prepare
- [ ] Execute
- [ ] Delegate

## Approval requirement

Does this need explicit user approval? Why?

## Implementation sketch

Which module should change?
