---
name: Model candidate
description: Evaluate a local or delegated model candidate
title: "Model candidate: "
labels: ["model", "research"]
---

## Model

Name, version and source.

## Intended role

- [ ] Native Apple layer
- [ ] Local agent brain
- [ ] Router / classifier
- [ ] Embedding model
- [ ] Delegated large model

## License

Summarize license constraints.

## Runtime

Which runtime should be tested?

## Benchmark plan

- cold start
- memory
- tokens/sec
- thermal behavior
- battery impact
- quality
- privacy behavior

## Decision

- [ ] Adopt
- [ ] Keep testing
- [ ] Reject
