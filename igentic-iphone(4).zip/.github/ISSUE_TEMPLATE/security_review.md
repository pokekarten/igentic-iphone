---
name: Security review
description: Review a privacy, security or delegation concern
title: "Security review: "
labels: ["security", "privacy"]
---

## Area

- [ ] PolicyEngine
- [ ] DataClassification
- [ ] ApprovalManager
- [ ] DelegationBroker
- [ ] AppIntentBridge
- [ ] Model runtime
- [ ] Storage / memory

## Concern

Describe the risk.

## Data classes involved

List all relevant data classes.

## Proposed mitigation

Describe the required guardrail.

## Tests required

Which tests should prove this is safe?
