---
name: Task slice
description: Small implementation task for the iGentic iPhone repo
title: "[Task]: "
labels: ["task", "needs-scope"]
body:
  - type: textarea
    id: goal
    attributes:
      label: Goal
      description: What should change?
    validations:
      required: true
  - type: textarea
    id: scope
    attributes:
      label: Scope
      description: Which files or layers may be changed?
    validations:
      required: true
  - type: textarea
    id: validation
    attributes:
      label: Validation
      description: Which commands or checks must pass?
    validations:
      required: true
  - type: textarea
    id: privacy
    attributes:
      label: Privacy impact
      description: Does this affect data classes, approvals, delegation, storage, or logging?
    validations:
      required: true
---
