## Scope

Describe the focused task this PR implements.

## Changed files

List the main files changed.

## Validation

- [ ] `node scripts/validate-repo.mjs`
- [ ] `cd ios && swift test`
- [ ] Other:

## Privacy and security impact

- Data classes changed? yes/no
- Approval requirements changed? yes/no
- External delegation changed? yes/no
- Secrets or credentials added? must be no

## Notes for review

Mention open questions, limitations, and anything intentionally deferred.
