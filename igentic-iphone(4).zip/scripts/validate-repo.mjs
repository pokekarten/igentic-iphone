import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const requiredFiles = [
  'README.md',
  'ARCHITECTURE.md',
  'PRIVACY.md',
  'MODEL_STRATEGY.md',
  'DELEGATION.md',
  'ROADMAP.md',
  'LICENSE',
  'docs/DECISIONS.md',
  'docs/COMMUNITY_STARTER_ISSUES.md',
  'docs/REPO_IMPORT_CHECKLIST.md',
  'docs/PR_REVIEW_CHECKLIST.md',
  'docs/CHATGPT_OPERATIONS.md',
  'docs/CODEX_PROMPT_TEMPLATE.md',
  'docs/ASSUMPTIONS.md',
  '.editorconfig',
  'PROJECT_STATE.md',

  'NOTICE',
  'CODE_OF_CONDUCT.md',
  'SECURITY.md',
  'GOVERNANCE.md',
  'SUPPORT.md',
  'docs/OPEN_SOURCE.md',
  '.github/labels.yml',
  '.github/ISSUE_TEMPLATE/config.yml',
  '.gitignore',
  '.github/ISSUE_TEMPLATE/task_slice.md',
  '.github/pull_request_template.md',
  'docs/CHATGPT_NEXT_TASK.md',
  'docs/CODEX_NEXT_TASK.md',
  'docs/TASK_BACKLOG.md',
  'docs/VALIDATION.md',
  'docs/BRANCH_STRATEGY.md',
  'docs/GITHUB_SETUP.md',
  'docs/WORKFLOW.md',
  'AGENTS.md',
  'CONTRIBUTING.md',
  'package.json',
  'docs/vision.md',
  'docs/iphone-air-hardware.md',
  'docs/offline-first.md',
  'docs/agent-loop.md',
  'docs/privacy-model.md',
  'docs/data-classes.md',
  'docs/app-intents.md',
  'docs/delegation.md',
  'docs/local-models.md',
  'docs/mcp-integration.md',
  'docs/related-projects.md',
  'docs/security-notes.md',
  'docs/sources.md',
  'ios/Package.swift',
  'ios/Sources/AgentCore/AgentKernel.swift',
  'ios/Sources/AgentCore/TaskRouter.swift',
  'ios/Sources/AgentCore/PolicyEngine.swift',
  'ios/Sources/AgentCore/PrivacyPolicy.swift',
  'ios/Sources/AgentCore/DataClassification.swift',
  'ios/Sources/AgentCore/LocalModelRuntime.swift',
  'ios/Sources/AgentCore/ToolRegistry.swift',
  'ios/Sources/AgentCore/AuditLog.swift',
  'ios/Sources/AgentCore/DelegationBroker.swift',
  'ios/Sources/AgentCore/ApprovalManager.swift',
  'ios/Sources/AgentCore/MemoryStore.swift',
  'ios/Sources/AgentIntents/AppIntentBridge.swift',
  'ios/Sources/AgentIntents/CreateReminderIntent.swift',
  'ios/Sources/AgentIntents/SummarizeNoteIntent.swift',
  'ios/Sources/AgentIntents/FindFileIntent.swift',
  'ios/Sources/AgentIntents/RequestApprovalIntent.swift',
  'ios/Sources/AgentUI/AgentStatusView.swift',
  'ios/Sources/AgentUI/PrivacyModeView.swift',
  'ios/Sources/AgentUI/AuditLogView.swift',
  'ios/Tests/AgentCoreTests/PolicyEngineTests.swift',
  'ios/Tests/AgentCoreTests/TaskRouterTests.swift',
  'ios/Tests/AgentCoreTests/DataClassificationTests.swift',
  '.github/workflows/swift.yml',
  '.github/ISSUE_TEMPLATE/feature_request.md',
  '.github/ISSUE_TEMPLATE/security_review.md',
  '.github/ISSUE_TEMPLATE/model_candidate.md'
];

const missing = requiredFiles.filter((file) => !existsSync(join(root, file)));
if (missing.length > 0) {
  console.error(`Missing required files:\n${missing.join('\n')}`);
  process.exit(1);
}

function walk(dir) {
  const result = [];
  for (const entry of readdirSync(dir)) {
    if (entry === '.git' || entry === '.build' || entry === '.swiftpm') continue;
    const full = join(dir, entry);
    const stat = statSync(full);
    if (stat.isDirectory()) result.push(...walk(full));
    else result.push(full);
  }
  return result;
}

const files = walk(root).filter((file) => !file.endsWith('.zip'));
const secretPatterns = [
  /sk-[A-Za-z0-9_-]{20,}/,
  /ghp_[A-Za-z0-9_]{20,}/,
  /-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----/,
  /AKIA[0-9A-Z]{16}/
];

for (const file of files) {
  const content = readFileSync(file, 'utf8');
  for (const pattern of secretPatterns) {
    if (pattern.test(content)) {
      console.error(`Potential secret found in ${file}`);
      process.exit(1);
    }
  }
}

const readme = readFileSync(join(root, 'README.md'), 'utf8');
for (const term of ['iGentic iPhone', 'Privacy-first', 'iPhone Air', 'Experimental / Research Prototype', 'Editable repo workflow']) {
  if (!readme.includes(term)) {
    console.error(`README is missing required term: ${term}`);
    process.exit(1);
  }
}



const workflowFiles = ['docs/CODEX_NEXT_TASK.md', 'docs/CHATGPT_NEXT_TASK.md', 'docs/WORKFLOW.md', 'AGENTS.md'];
for (const file of workflowFiles) {
  const content = readFileSync(join(root, file), 'utf8');
  if (!content.includes('Codex') && file.includes('CODEX')) {
    console.error(`${file} does not describe Codex workflow.`);
    process.exit(1);
  }
  if (!content.includes('ChatGPT') && file.includes('CHATGPT')) {
    console.error(`${file} does not describe ChatGPT workflow.`);
    process.exit(1);
  }
}

console.log(`Repository skeleton OK: ${requiredFiles.length} required files present, ${files.length} files scanned.`);


const packageJson = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
if (packageJson.private === true) {
  console.error('package.json must not be marked private for the public open-source starter repo.');
  process.exit(1);
}
if (packageJson.license !== 'Apache-2.0') {
  console.error('package.json must declare Apache-2.0 license.');
  process.exit(1);
}

const licenseText = readFileSync(join(root, 'LICENSE'), 'utf8');
if (!licenseText.includes('Apache License')) {
  console.error('LICENSE must contain Apache License text.');
  process.exit(1);
}


if (readme.includes('MIT. See [`LICENSE`](LICENSE)')) {
  console.error('README must not say MIT; this repo is Apache-2.0 licensed.');
  process.exit(1);
}

const githubSetup = readFileSync(join(root, 'docs/GITHUB_SETUP.md'), 'utf8');
if (!githubSetup.includes('Visibility: Public') || !githubSetup.includes('--public')) {
  console.error('docs/GITHUB_SETUP.md must make public repo setup the default.');
  process.exit(1);
}
if (githubSetup.includes('--private')) {
  console.error('docs/GITHUB_SETUP.md must not recommend --private for this open-source starter.');
  process.exit(1);
}

const projectState = readFileSync(join(root, 'PROJECT_STATE.md'), 'utf8');
for (const term of ['igentic-iphone', 'Experimental / Research Prototype', 'Apache-2.0', 'public from first import']) {
  if (!projectState.includes(term)) {
    console.error(`PROJECT_STATE.md is missing required term: ${term}`);
    process.exit(1);
  }
}

for (const forbiddenDir of ['ios/.build', '.swiftpm', 'node_modules']) {
  if (existsSync(join(root, forbiddenDir))) {
    console.error(`Generated dependency/build directory must not be committed: ${forbiddenDir}`);
    process.exit(1);
  }
}
