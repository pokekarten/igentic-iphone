# Open Source Launch Plan

## Repository setup

Recommended GitHub settings for the first public launch:

- Repository name: `igentic-iphone`
- Visibility: Public
- License: Apache-2.0
- Issues: enabled
- Pull requests: enabled
- Discussions: enabled after the initial import
- Wiki: disabled at first; keep docs in the repository
- Projects: optional; use issues first

## Repository description

`Privacy-first iPhone AI Runtime Layer for local agents, secure App Intents, and controlled delegation.`

## Topics

Use focused topics so contributors can discover the project:

- `ios`
- `swift`
- `apple-intelligence`
- `core-ml`
- `app-intents`
- `on-device-ai`
- `local-first`
- `privacy`
- `ai-agents`
- `llm`
- `mlx`
- `mcp`
- `iphone`
- `edge-ai`

## Initial labels

Recommended labels:

- `good first issue`
- `help wanted`
- `documentation`
- `architecture`
- `privacy`
- `security-review`
- `ios`
- `swift`
- `app-intents`
- `local-models`
- `delegation`
- `offline-first`
- `model-evaluation`
- `needs-design`
- `blocked`
- `research`

## First public issues

Create a small set of starter issues:

1. `Document supported iOS and Xcode target versions`
2. `Evaluate first safe App Intent prototype`
3. `Define encrypted MemoryStore persistence strategy`
4. `Compare Qwen3-1.7B, Qwen3-4B, Llama 3.2 3B, Gemma small variants`
5. `Design Trusted Device delegation handshake`
6. `Add a minimal sample app target`
7. `Add privacy threat model for external AI delegation`
8. `Create contributor-friendly architecture diagram`

## Launch principle

Open source does not mean uncontrolled autonomy. The repository should invite collaboration while keeping privacy, security, user approval, and auditability as merge-blocking requirements.


## Maintainer workflow

- Keep `PROJECT_STATE.md` current.
- Keep first issues small and labeled.
- Use `good first issue` only for tasks that can be completed without Apple Developer account access, model downloads, or private data.
- Use `security-review` for privacy, approval, delegation, audit, or data-class changes.
- Prefer Discussions for broad architecture debate after the first import is stable.

## Import checklist

See `docs/REPO_IMPORT_CHECKLIST.md` before pushing the ZIP to GitHub.
