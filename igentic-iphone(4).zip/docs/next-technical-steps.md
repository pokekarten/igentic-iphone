# Next Technical Steps

## Step 1: Create fresh GitHub repository

Create a new repository named `igentic-iphone` and upload this skeleton as the initial commit.

## Step 2: Run baseline validation

```bash
node scripts/validate-repo.mjs
cd ios
swift test
```

## Step 3: Decide first real iOS app shape

This skeleton is a Swift package. The next step is an actual iOS app target with:

- status screen
- privacy mode selector
- approval sheet
- audit log view
- local-only task demo

## Step 4: Implement persistent audit log

Start with local JSON persistence, then move to encrypted storage.

## Step 5: Add real App Intents prototype

Implement a minimal App Intent for reminder drafts. Keep execution separate from preparation.

## Step 6: Benchmark local model runtimes

Create a benchmark matrix for:

- Apple Foundation Models where available
- Core AI / Core ML
- MLX Swift
- MLC-LLM
- llama.cpp-derived runtime
- Qwen3-4B quantized
- a small router model

## Step 7: Add Privacy Broker tests

Before any external call exists, write tests for:

- Level 4 never external
- Level 3 approval required
- local-only mode denies external delegation
- critical actions require approval
- redaction runs before delegation
