# Task Backlog

## Immediate

1. Verify repo import and CI.
2. Implement a typed `AgentRequest` and `AgentDecision` model.
3. Add tests for the full data-class policy matrix.
4. Add audit-log redaction tests.
5. Add approval-state transitions.

## Next

1. Add local model runtime protocol adapters without real model dependencies.
2. Add App Intent documentation and compile-time stubs for iOS-only targets.
3. Define local memory scopes and retention rules.
4. Define delegation job schema.
5. Add privacy broker test cases.

## Later

1. Evaluate MLX Swift example integration.
2. Evaluate Core AI / Core ML model adapter.
3. Test Qwen3-1.7B as router on Apple silicon.
4. Test Qwen3-4B quantized as local agent candidate.
5. Prototype trusted Mac worker.
