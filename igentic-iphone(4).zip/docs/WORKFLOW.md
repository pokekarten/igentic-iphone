# Repository Workflow

This repo is designed to be editable after import into GitHub. The workflow mirrors a lightweight ChatGPT + Codex loop.

## Roles

### Human owner

- Creates the fresh GitHub repository.
- Uploads or pushes this skeleton.
- Approves sensitive direction changes.
- Decides when to move from research prototype to app prototype.

### ChatGPT

- Maintains product strategy and architecture consistency.
- Reads repo state through GitHub when available.
- Slices work into small tasks.
- Updates `docs/CODEX_NEXT_TASK.md` before asking Codex to implement.
- Reviews Codex PRs against scope, privacy rules, changed files, and tests.

### Codex or coding agent

- Works only on the active scoped task.
- Uses the branch from `docs/CODEX_NEXT_TASK.md`.
- Runs validation before reporting.
- Stops at stop rules instead of improvising around security or platform limitations.

## Standard loop

1. ChatGPT checks the repo state.
2. ChatGPT updates `docs/CODEX_NEXT_TASK.md`.
3. Human starts Codex with the task.
4. Codex creates a small draft PR.
5. ChatGPT reviews PR scope, diff, and checks.
6. Human merges only after review.
7. ChatGPT updates `docs/CHATGPT_NEXT_TASK.md` and roadmap notes.

## Small-task rule

A good task changes one layer only:

- docs only
- AgentCore only
- tests only
- AppIntent skeleton only
- delegation protocol skeleton only
- model runtime adapter skeleton only

Avoid tasks that combine policy, model runtime, networking, UI, and docs in one PR.

## Validation commands

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Root convenience script:

```bash
npm run check
```

or:

```bash
bun run check
```

## When to stop

Stop and ask for human review if a proposed change:

- sends data to a third party
- changes data classification rules
- adds background execution
- adds a real model runtime dependency
- uses private Apple APIs
- stores personal raw data without retention rules
- bypasses approvals


## Standard ChatGPT output for Codex tasks

When ChatGPT decides Codex should implement something, the user-facing answer should be minimal:

```text
Task needed: yes/no
Base branch: main
Working branch: codex/<task-name>
Copy-paste prompt:
<short prompt based on docs/CODEX_PROMPT_TEMPLATE.md>
```

Do not paste broad architecture docs into Codex prompts. Keep persistent rules in `AGENTS.md` and the exact implementation scope in `docs/CODEX_NEXT_TASK.md`.

## First task after import

The first task after GitHub import is not a feature. It is repo verification: run validator and Swift tests, confirm the repo is editable, and report whether normal feature branches can start.
