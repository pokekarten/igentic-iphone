# Offline-first Mode

Offline is not a fallback. It is the base operating mode.

## Should work offline

- understand short user commands
- summarize local text
- structure notes
- detect tasks
- analyze local calendar context if permission exists
- create reminder drafts
- search local documents
- build simple agent plans
- draft messages or emails
- local RAG search
- apply local preferences
- prepare tool selection
- prepare action drafts

## Not ideal offline on iPhone Air

- very large models
- long multi-agent sessions
- large batch analyses
- high-quality image generation
- video generation
- large codebase analysis
- hour-long background jobs

## Offline policy

When offline:

- deny external model calls
- queue allowed trusted-device jobs only if destination is unavailable
- keep audit logs local
- expose limitations clearly to the user
- never silently fall back to cloud
