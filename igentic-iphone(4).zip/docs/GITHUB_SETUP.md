# GitHub Setup

The target repository is a new fresh public repo named `igentic-iphone`.

## Create the repo

Recommended fields in the GitHub web UI:

```text
Owner: <your organization or user, e.g. pokekarten now, igentic later if created>
Repository name: igentic-iphone
Description: Privacy-first iPhone AI Runtime Layer for local agents, secure App Intents, and controlled delegation.
Visibility: Public
```

Do **not** enable these GitHub starter options when creating the repo:

```text
Add README: off
Add .gitignore: off
Choose a license: off
```

This ZIP already contains `README.md`, `.gitignore`, and `LICENSE`. Adding GitHub-generated starter files can create avoidable merge conflicts on first import.

## Push from a local machine

```bash
unzip igentic-iphone.zip
cd igentic-iphone
git init
git add .
git commit -m "Initial iGentic iPhone starter repo"
git branch -M main
git remote add origin git@github.com:<owner>/igentic-iphone.git
git push -u origin main
```

## GitHub CLI alternative

```bash
unzip igentic-iphone.zip
cd igentic-iphone
git init
git add .
git commit -m "Initial iGentic iPhone starter repo"
gh repo create igentic-iphone --public --source=. --remote=origin --push
```

## After import

Run locally or in a coding-agent workspace:

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Then tell ChatGPT the real repo full name, for example:

```text
Repo erstellt: pokekarten/igentic-iphone
```

ChatGPT should then read `PROJECT_STATE.md`, `AGENTS.md`, `docs/WORKFLOW.md`, `docs/CHATGPT_NEXT_TASK.md`, and `docs/CODEX_NEXT_TASK.md` through the GitHub connector before preparing the first real task.

## Repository settings

Recommended public settings after import:

- Issues: enabled
- Pull requests: enabled
- Discussions: enabled after initial import
- Wiki: disabled at first; keep docs versioned in the repo
- Actions: enabled for the small Swift validation workflow

Recommended topics are listed in `docs/OPEN_SOURCE.md`.
