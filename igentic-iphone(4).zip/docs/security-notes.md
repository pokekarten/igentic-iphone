# Security Notes

## Threats

- accidental external leakage of private context
- prompt injection through local documents
- tool misuse
- overbroad permissions
- insecure delegation target
- untrusted model output triggering actions
- secrets in logs
- background execution without clear user awareness

## Required mitigations

- data classification
- policy engine
- approval manager
- prompt injection resistant retrieval design
- redaction before delegation
- local audit logs
- least privilege tool interfaces
- no raw secrets in prompts
- result verification before action

## App Store and platform limits

The project must respect iOS sandboxing, permission prompts, background execution limits and App Store review constraints.

## Research prototype status

This repository is a skeleton and does not yet implement production security controls.
