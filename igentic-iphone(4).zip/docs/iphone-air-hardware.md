# iPhone Air Hardware Strategy

## CPU

Use CPU for:

- agent loop orchestration
- policy evaluation
- routing
- parsing
- task scheduling
- redaction
- audit log processing

## GPU

Use GPU for:

- generative local models
- LLM inference
- batch processing
- larger matrix operations

## Neural Engine

Use Neural Engine / Apple ML acceleration where exposed through supported APIs for:

- Core ML / Core AI models
- classification
- embeddings
- vision tasks
- efficient lightweight inference

Avoid claiming direct unrestricted Neural Engine programming. Use public frameworks first.

## Storage

Use local storage for:

- model weights
- local vector index
- document index
- memory store
- audit logs
- offline knowledge base

Future storage must support encryption, deletion and scope management.

## Secure Enclave / Keychain

Use for:

- keys
- tokens
- identity material
- approval state
- encryption keys
- sensitive local secrets

The starter repository does not implement secure storage yet; it defines the intended boundary.

## Thermal and battery stance

iPhone Air should not be treated as a server. Long-running background jobs, sustained 7B/8B inference, video generation and large codebase analysis should be delegated.
