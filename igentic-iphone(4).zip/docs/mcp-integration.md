# MCP Integration

Model Context Protocol can become useful for trusted-device delegation and tool interoperability.

## Potential roles

- iPhone as MCP client for trusted tools
- Mac as MCP server exposing local compute
- home server as MCP server exposing private index or queue
- app-specific MCP tools with strict policy metadata

## Security posture

MCP integration must not bypass the local policy engine.

Required gates:

- tool manifest review
- capability classification
- destination trust level
- argument redaction
- approval for sensitive tool calls
- audit logging

## Starter stance

This repository does not include MCP as a dependency yet. It documents MCP as a future integration path.
