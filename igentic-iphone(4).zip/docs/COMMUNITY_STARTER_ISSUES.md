# Community Starter Issues

These are suggested first public issues. Keep them small and contributor-friendly.

## Good first issue candidates

1. Document supported iOS, macOS, Swift and Xcode versions.
2. Add an architecture diagram as Mermaid in `ARCHITECTURE.md`.
3. Expand the data-class examples in `docs/data-classes.md`.
4. Add tests for redacted audit log entries.
5. Add a model evaluation template for Qwen3-1.7B, Qwen3-4B, Llama 3.2 3B, Gemma small variants, and Phi-4-mini.
6. Add a glossary for App Intents, Private Cloud Compute, Core AI, Core ML, MLX, and MCP.

## Help wanted candidates

1. Design the encrypted MemoryStore persistence strategy.
2. Research safe App Intents boundaries for reminders, files, notes, and calendar.
3. Compare trusted-device delegation protocols: Network Framework, Multipeer Connectivity, MCP, and a custom local protocol.
4. Build a minimal sample app target after AgentCore is stable.
5. Define the first real on-device model benchmark plan.

## Security-review candidates

1. Threat model for external AI delegation.
2. Approval bypass analysis for critical actions.
3. Redaction and minimization strategy for private context.
4. Audit log retention and deletion policy.
