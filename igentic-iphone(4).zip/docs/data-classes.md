# Data Classes

## Level 0: Public

Examples:

- public docs
- open-source model metadata
- public websites

Policy:

- local automatic use allowed
- delegation allowed if useful

## Level 1: Low-risk app data

Examples:

- local app settings
- non-sensitive preferences
- UI state

Policy:

- local automatic use allowed
- delegation allowed with minimization

## Level 2: Personal task context

Examples:

- calendar
- notes
- files
- reminders

Policy:

- use only for a concrete task
- delegation requires purpose and minimization

## Level 3: Sensitive personal context

Examples:

- contacts
- messages
- precise location

Policy:

- explicit approval required
- external delegation must be exceptional and minimized

## Level 4: Highly sensitive

Examples:

- health
- finance
- identity documents
- keys
- secrets

Policy:

- never automatically delegate
- prefer local-only handling
- require strong approval even for local critical actions
