# Validation

The repository has two validation layers.

## Structural validator

From the root:

```bash
node scripts/validate-repo.mjs
```

This checks:

- required files exist
- common secret patterns are absent
- README contains required project markers
- workflow files exist
- ChatGPT/Codex task files exist

## Swift tests

From `ios/`:

```bash
swift test
```

The Swift package currently tests pure `AgentCore` logic so it can run before a full iOS app exists.

## CI

GitHub Actions workflow:

```text
.github/workflows/swift.yml
```

The workflow runs on PRs and pushes to `main`.

## Validation philosophy

Do not add a feature that cannot be validated at the correct layer. Early validation should prefer pure Swift tests and policy tests over UI tests or device-only behavior.
