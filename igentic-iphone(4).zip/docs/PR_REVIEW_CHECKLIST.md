# PR Review Checklist

Use this checklist for every Draft PR before merge.

## Identity and branch

- Repo is `<owner>/igentic-iphone`.
- Base branch is `main`.
- Working branch matches `codex/<task-name>` or documented human branch.
- PR is a Draft PR until review passes.

## Scope

- PR implements only `docs/CODEX_NEXT_TASK.md` or a clearly linked issue.
- No broad rewrites.
- No unrelated formatting churn.
- No generated build artifacts.
- No model weights or large binaries.

## Validation

Required unless explicitly blocked and documented:

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

## Privacy and safety

- No secrets or tokens.
- No personal data fixtures.
- No silent external calls.
- No weakening of data classification rules.
- Critical actions still require approval.
- External delegation includes minimization and audit design.

## Documentation

- `PROJECT_STATE.md` updated if repo state changed.
- `docs/CHATGPT_NEXT_TASK.md` updated if next ChatGPT action changed.
- `docs/CODEX_NEXT_TASK.md` updated or reset if the task is complete.
- Architecture docs updated for non-trivial design changes.

## Merge recommendation

Use one of:

- `merge recommended`
- `needs fixes`
- `blocked: <reason>`
