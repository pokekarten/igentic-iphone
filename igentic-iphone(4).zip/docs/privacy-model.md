# Privacy Model

The project uses a local-first privacy model.

## Rules

- classify data before use
- prefer local processing
- minimize context before delegation
- redact identifiers where possible
- require approval for sensitive data and critical actions
- write audit logs
- make logs deletable

## Critical actions

Critical actions include:

- sending messages
- moving or deleting files
- creating, moving or deleting calendar events
- purchases or irreversible transactions
- external data sharing
- changing privacy settings
- storing credentials

Critical actions require explicit approval.
