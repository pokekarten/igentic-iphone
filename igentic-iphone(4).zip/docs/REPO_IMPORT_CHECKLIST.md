# Repo Import Checklist

## Before creating GitHub repo

- Repository name is `igentic-iphone`.
- Visibility is `Public`.
- Starter README is disabled.
- Starter `.gitignore` is disabled.
- Starter license is disabled.
- ZIP used is the latest `igentic-iphone.zip` or `igentic-iphone-open-source-ready.zip`.

## After first push

Run:

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Then set repository metadata:

- Description: `Privacy-first iPhone AI Runtime Layer for local agents, secure App Intents, and controlled delegation.`
- Website: empty for now
- Topics: see `docs/OPEN_SOURCE.md`

Enable:

- Issues
- Pull requests
- Discussions after initial import
- Actions for the Swift validation workflow

Disable for now:

- Wiki

## First message back to ChatGPT

```text
Repo erstellt: <owner>/igentic-iphone
```

ChatGPT should then use the GitHub connector as the source of truth and continue from `PROJECT_STATE.md`.
