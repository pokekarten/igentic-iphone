# Delegation

Delegation is controlled compute, not delegated trust.

## Target order

1. Local iPhone execution
2. Trusted Mac or iPad
3. Home server
4. Private Cloud Compute where available and appropriate
5. External AI provider after explicit approval

## Delegation decision

A future `DelegationBroker` should consider:

- data class
- operating mode
- model requirement
- latency
- thermal pressure
- battery level
- network trust
- user approval
- destination capabilities

## Result verification

Delegated output should be checked locally before it triggers an action.
