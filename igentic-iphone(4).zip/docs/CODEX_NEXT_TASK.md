# Codex Next Task

Status: ready

## Task

Verify the first GitHub-imported version of `igentic-iphone` after this ZIP is pushed to a fresh public repository.

## Goal

Confirm that the repository is editable, testable, public-open-source-ready, and ready for small incremental agent work. Do not add feature code yet unless validation exposes a concrete import breakage.

## Base branch

`main`

## Working branch

`codex/verify-editable-starter-repo`

## Required first checks

```bash
git remote -v
git status --branch --short
git branch --show-current
```

Stop if the checkout is not connected to the expected GitHub repository `<owner>/igentic-iphone`.

## Scope

Allowed:

- inspect repository structure
- run validation commands
- fix broken imports, package metadata, workflow path issues, or Swift test failures
- improve only small workflow documentation if validation reveals a concrete gap
- update `PROJECT_STATE.md` if the verification changes the project state

Not allowed:

- no model downloads
- no model weights
- no external API calls
- no secrets
- no app-store configuration
- no large feature implementation
- no privacy-policy weakening
- no generated build artifacts

## Required validation commands

```bash
node scripts/validate-repo.mjs
cd ios && swift test
```

Root convenience commands are also available:

```bash
npm run check
bun run check
```

## Expected result

- validation passes
- Swift tests pass or a platform limitation is clearly documented
- no large file additions
- no generated build artifacts committed
- a short report confirms whether the repo is ready for normal feature branches
- a real Draft PR into `main` exists if files changed

## Stop rules

Stop and report instead of continuing if:

- the package cannot be tested without a real iOS SDK or Xcode-only dependency
- a change would require adding secrets, credentials, provisioning profiles, or model weights
- a change would send private user data to an external system
- a task requires changing the core privacy model without explicit review
- the GitHub checkout is disconnected or points to the wrong repository

## Review checklist for ChatGPT

- Confirm only allowed files changed.
- Confirm tests and validator output.
- Confirm no secrets or build artifacts.
- Confirm `PROJECT_STATE.md` reflects the true repo state.
- Confirm `docs/CHATGPT_NEXT_TASK.md` still matches the actual next non-Codex task.
