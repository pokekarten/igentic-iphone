# Sources

These sources should be rechecked before making final implementation decisions. Apple APIs, model licenses, deployment targets and app store rules can change quickly.

## Apple

- Apple Intelligence: https://developer.apple.com/apple-intelligence/
- Apple Foundation Models Framework: https://developer.apple.com/documentation/FoundationModels
- Apple Foundation Models Newsroom: https://www.apple.com/newsroom/2025/09/apples-foundation-models-framework-unlocks-new-intelligent-app-experiences/
- Apple Machine Learning Research, Apple Foundation Models: https://machinelearning.apple.com/research/introducing-third-generation-of-apple-foundation-models
- Core AI: https://developer.apple.com/core-ai/
- Core ML: https://developer.apple.com/documentation/coreml
- App Intents: https://developer.apple.com/documentation/appintents
- App Intents with Siri and Apple Intelligence: https://developer.apple.com/documentation/appintents/integrating-actions-with-siri-and-apple-intelligence
- App Shortcuts: https://developer.apple.com/documentation/appintents/app-shortcuts
- Private Cloud Compute Security: https://security.apple.com/blog/private-cloud-compute/
- Apple iPhone Guide, Apple Intelligence and PCC: https://support.apple.com/en-mt/guide/iphone/iphe3f499e0e/ios
- Apple Platform Security, runtime process security: https://support.apple.com/guide/security/security-of-runtime-process-sec15bfe098e/web
- Apple Secure Enclave: https://support.apple.com/guide/security/the-secure-enclave-sec59b0b31ff/web
- BackgroundTasks: https://developer.apple.com/documentation/BackgroundTasks/performing-long-running-tasks-on-ios-and-ipados
- Background Tasks Strategy: https://developer.apple.com/documentation/backgroundtasks/choosing-background-strategies-for-your-app
- Background URLSession: https://developer.apple.com/documentation/foundation/downloading-files-in-the-background
- Multipeer Connectivity: https://developer.apple.com/documentation/multipeerconnectivity
- Network Framework: https://developer.apple.com/documentation/network
- iPhone Air Specs: https://www.apple.com/de/iphone-air/specs/
- iPhone Air support specs: https://support.apple.com/en-us/125092

## Local runtimes and models

- Apple MLX: https://opensource.apple.com/projects/mlx
- MLX Swift: https://github.com/ml-explore/mlx-swift
- Apple coreai-models: https://github.com/apple/coreai-models
- MLC-LLM: https://github.com/mlc-ai/mlc-llm
- llama.cpp: https://github.com/ggerganov/llama.cpp
- LLM Farm: https://github.com/guinmoon/llmfarm
- PocketPal: https://github.com/a-ghorbani/pocketpal-ai
- Locally AI: https://apps.apple.com/us/app/locally-ai/id6476198148
- Qwen3: https://qwen.ai/blog?id=qwen3
- Qwen3-4B: https://huggingface.co/Qwen/Qwen3-4B
- Llama 3.2: https://ai.meta.com/blog/llama-3-2-connect-2024-vision-edge-mobile-devices/
- Gemma 3: https://deepmind.google/models/gemma/gemma-3/
- Gemma docs: https://ai.google.dev/gemma/docs/core
- Phi-4-mini: https://huggingface.co/microsoft/Phi-4-mini-instruct

## Agents and protocols

- OpenClaw: https://openclaw.ai/
- OpenClaw GitHub: https://github.com/openclaw/openclaw
- OpenClaw iOS docs: https://docs.openclaw.ai/platforms/ios
- SemaClaw: https://github.com/midea-ai/SemaClaw
- OpenJarvis: https://github.com/OpenJarvisAI/OpenJarvis
- Model Context Protocol: https://modelcontextprotocol.io/
- MCP Swift SDK: https://github.com/modelcontextprotocol/swift-sdk

## Comparison systems

- Android Gemini Nano / AICore: https://developer.android.com/ai/gemini-nano
- Android Private Compute Services: https://github.com/google/private-compute-services
- Windows AI APIs: https://learn.microsoft.com/en-us/windows/ai/apis/

## Research and discussion

- Apple Silicon LLM Benchmark: https://github.com/john-rocky/apple-silicon-llm-bench
- Wccftech CoreAI vs MLX discussion: https://wccftech.com/apples-new-coreai-engine-barely-edges-out-its-own-mlx-framework-at-realistic-8b-model-sizes-despite-being-2-47x-faster-on-tiny-models/
- OS-integrated AI privacy risks: https://arxiv.org/abs/2606.10173
- Agent security / OpenClaw-like risk: https://arxiv.org/abs/2604.04759
