# Agent Loop

The agent loop is intentionally bounded and auditable.

1. Receive user request.
2. Understand intent.
3. Determine required data.
4. Classify data.
5. Select local tools or models.
6. Build a small plan.
7. Ask for clarification only when necessary.
8. Execute a local tool or prepare an action.
9. Ask for approval for critical actions.
10. Verify result.
11. Write audit log.
12. Return response.

## Agent kernel modules

- `TaskRouter`
- `PolicyEngine`
- `LocalModelRuntime`
- `ToolRegistry`
- `AppIntentBridge`
- `MemoryStore`
- `AuditLog`
- `DelegationBroker`
- `PrivacyBroker`
- `ApprovalManager`
- `CapabilityRegistry`

## Bounded autonomy

The agent should not run as an unconstrained super-agent. It should operate as a controlled kernel with explicit surfaces and policy gates.
