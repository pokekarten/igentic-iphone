# Codex Prompt Template

Use this only after ChatGPT has updated `docs/CODEX_NEXT_TASK.md`.

## Minimal copy-paste prompt

```text
Use the connected GitHub repository checkout for <owner>/igentic-iphone.

Read and follow:
- AGENTS.md
- PROJECT_STATE.md
- docs/CODEX_NEXT_TASK.md

Implement only the task described in docs/CODEX_NEXT_TASK.md.
Use base branch: main
Use working branch from the task file.
Create a real GitHub Draft PR into main if files change.

Before changing files, run:
git remote -v
git status --branch --short
git branch --show-current

Stop immediately if the checkout is not connected to <owner>/igentic-iphone.

Before reporting, run:
node scripts/validate-repo.mjs
cd ios && swift test

Do not add secrets, model weights, generated build artifacts, external API calls, or broad feature changes.
Report changed files, validation output, and the Draft PR link only if the PR really exists.
```

## ChatGPT response format when giving Ben a Codex task

```text
Task needed: yes/no
Base branch: main
Working branch: codex/<task-name>
Copy-paste prompt:
...
```

Keep the prompt short. Put persistent rules in `AGENTS.md`, not in every Codex prompt.
