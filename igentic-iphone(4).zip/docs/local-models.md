# Local Models

## Local Brain layers

1. Apple-native intelligence layer.
2. Free controllable local model layer.
3. Small router model layer.
4. Local embedding model layer.
5. Delegated large model layer.

## Recommended first experiments

- deterministic `TaskRouter` baseline
- small intent classifier
- quantized Qwen3-4B runtime test
- local embedding model for private RAG
- compare Core AI, MLX Swift, MLC-LLM and llama.cpp-derived runtimes

## Benchmark dimensions

- cold start time
- tokens per second
- memory use
- battery drain
- thermal throttling
- answer quality for local tasks
- tool-selection reliability
- privacy policy compliance
