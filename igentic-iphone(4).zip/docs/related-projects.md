# Related Projects and Inspiration

## Apple-native

- Apple Intelligence
- Foundation Models framework
- Core AI
- Core ML
- App Intents
- App Shortcuts
- Private Cloud Compute
- BackgroundTasks
- Multipeer Connectivity
- Network Framework

## Local LLM runtimes

- MLX Swift
- MLX
- MLC-LLM
- llama.cpp
- LLM Farm
- PocketPal
- Locally AI

## Agent and personal AI projects

- OpenClaw
- SemaClaw
- OpenJarvis
- MCP Swift SDK
- Model Context Protocol

## Comparison systems

- Android Gemini Nano / AICore
- Android Private Compute Services
- Windows AI APIs / Copilot+ local AI APIs

## How to use this list

Do not copy architecture blindly. Use these projects as comparison points for:

- local runtime feasibility
- mobile constraints
- agent security risks
- tool execution design
- user approval patterns
- privacy boundaries
