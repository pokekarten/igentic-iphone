# App Intents and Safe Actions

## Principle

The agent should not click through the iPhone UI. It should act through safe, typed interfaces.

## Candidate interfaces

- App Intents
- App Shortcuts
- EventKit
- Contacts
- Files
- local app APIs
- custom tool interfaces
- future MCP bridge

## Example tools

- `readCalendar()`
- `createReminder()`
- `draftMessage()`
- `findFile()`
- `summarizeNote()`
- `startShortcut()`
- `requestApproval()`
- `createTask()`
- `searchLocalMemory()`
- `delegateToMac()`
- `delegateToHomeServer()`
- `runLocalModel()`
- `verifyResult()`

## Safety tiers

### Read

Usually allowed locally when permission exists and data class permits.

### Prepare

Allowed locally. The agent can draft a message or propose a calendar event.

### Execute

Requires confirmation when action is critical or irreversible.
