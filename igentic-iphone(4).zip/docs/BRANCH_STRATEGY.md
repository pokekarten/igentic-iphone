# Branch Strategy

This repository should stay easy to review.

## Main branch

`main` must remain green and conceptually coherent. It should not contain generated build outputs, model weights, secrets, or unfinished broad experiments.

## Branch prefixes

- `codex/*`: implementation task executed by Codex or a coding agent.
- `chatgpt/*`: small maintenance or documentation changes prepared by ChatGPT.
- `docs/*`: documentation-only work.
- `spike/*`: experimental branch that may be discarded.
- `security/*`: security or privacy model changes.

## Draft PR default

New capability branches should start as draft PRs. Mark a PR ready only when:

- validation passes
- tests pass
- privacy impact is described
- changed files match the requested scope
- no stop rule was ignored

## Merge preference

Prefer squash merge for small branches so the history stays readable.
