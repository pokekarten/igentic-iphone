# Assumptions and Verification Status

This file separates verified facts from planning assumptions. Recheck it before implementing platform- or model-specific features.

## Verified from current public sources

### Apple Intelligence / Foundation Models / App Intents

Apple describes Apple Intelligence as a personal intelligence system with personal context understanding, app actions, and on-screen awareness. Apple also describes App Intents as the integration path for app content and actions into Siri and Apple Intelligence, and describes the Foundation Models framework as a native Swift API for Apple Foundation Models and other providers conforming to Apple's language model protocol.

Implementation status in this repo: documented and planned only. No production Foundation Models integration yet.

### Core AI

Apple describes Core AI as an on-device Apple silicon model layer with a memory-safe Swift API. Apple `coreai-models` currently documents export recipes and Swift runtime utilities for Core AI models, with platform/tooling requirements that may be newer than this package's baseline.

Implementation status in this repo: evaluation target only. Do not add Core AI code until platform requirements are intentionally updated.

### iPhone Air hardware

Apple's iPhone Air specs list A19 Pro, 6-core CPU, 5-core GPU with Neural Accelerators, and 16-core Neural Engine.

Implementation status in this repo: used as target-device assumption for architecture and benchmarking plans.

### Qwen3-4B

Qwen3-4B is listed on Hugging Face with Apache-2.0 license and 4.0B parameters. It is a candidate, not a proven iPhone Air runtime choice yet.

Implementation status in this repo: candidate only. No model weights or runtime dependency are included.

### Open-source setup

The repo includes a detectable Apache-2.0 license, README, contributing guide, code of conduct, security policy, governance notes, and issue/PR templates.

Implementation status in this repo: included.

## Planning assumptions that must be benchmarked

- 1B-class models should be comfortable for routing and lightweight tasks.
- 3B-class models are likely the practical local sweet spot.
- Quantized 4B-class models are plausible for bounded sessions.
- 7B/8B-class models are likely edge cases on iPhone Air and should be delegated for sustained work.
- Long-running autonomous background operation is not the right iPhone default.

These are not performance claims. They must be validated with real device tests before being advertised.

## Design constraints derived from the sources

- Keep AgentCore testable without device-only frameworks.
- Treat Apple-native frameworks as preferred system integration paths, not as a full replacement for an open local model strategy.
- Treat Core AI as an evaluation path until OS/Xcode requirements are accepted.
- Keep local model experiments isolated from privacy-policy changes.
- Never ship model weights or private user data in the repo.
