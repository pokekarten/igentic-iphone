# ChatGPT Next Task

Status: ready

## Purpose

This file keeps the project editable through ChatGPT without losing the operating model. It is for repository steering, architecture review, task slicing, and GitHub/Codex coordination.

## Next ChatGPT task after GitHub import

When Ben says `Repo erstellt: <owner>/igentic-iphone`:

1. Use the GitHub connector to verify the real repository exists.
2. Confirm it is a fresh `igentic-iphone` repository, not an older project.
3. Read `PROJECT_STATE.md`, `AGENTS.md`, `CONTRIBUTING.md`, `docs/WORKFLOW.md`, `docs/ASSUMPTIONS.md`, and `docs/CODEX_NEXT_TASK.md`.
4. Check recent issues and PRs.
5. If the import is clean, prepare the first Codex verification task from `docs/CODEX_NEXT_TASK.md`.
6. If files are missing or the repo was initialized with conflicting GitHub starter files, prepare a repair task first.

## Current recommended next product slice

After the repo has passed import verification: build the first real `AgentRequest` → `TaskRouter` → `PolicyEngine` → `ApprovalManager` flow as a pure Swift package feature. Do not integrate App Intents or local model runtimes yet.

## Why this slice

It proves the core architecture without depending on device-only Apple frameworks, Xcode provisioning, local LLMs, or model downloads.

## Acceptance criteria for the first product slice

- A simple request can be classified.
- Policy returns whether local execution, approval, or denial is required.
- An approval request can be represented without executing a real iOS action.
- Audit log records the decision without storing raw sensitive data.
- Tests cover data classes 0-4.

## ChatGPT operating rules

- Use GitHub connector reads/reviews once the repo exists.
- Use Codex only for bounded implementation tasks.
- Keep prompts short and file-scoped.
- Before each Codex task, write or update `docs/CODEX_NEXT_TASK.md`.
- After each Codex draft PR, independently review the diff and tests.
- Do not ask Codex to do broad research when ChatGPT can prepare the task.
- Do not merge or recommend merge if validation, privacy, or scope checks fail.
