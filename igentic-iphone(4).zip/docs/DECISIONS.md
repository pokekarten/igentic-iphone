# Architecture Decisions

## ADR-0001: Public open-source from first import

Decision: The repo should be public and Apache-2.0 licensed from the first import.

Reason: The project is a research prototype that benefits from transparent architecture review, privacy/security feedback, and community model/runtime evaluation.

Consequence: No secrets, model weights, private data, or proprietary app-store assets can be committed.

## ADR-0002: Deterministic AgentCore before model runtime

Decision: Build and test `AgentCore` before integrating Apple Foundation Models, Core AI, MLX, MLC-LLM, llama.cpp, or Qwen.

Reason: Privacy policy, routing, approval, and audit behavior must be correct before the agent gains model-driven capability.

Consequence: The first implementation tasks should be Swift package logic and tests, not model downloads.

## ADR-0003: iPhone as trust/control plane

Decision: The iPhone is the trust and control plane. Mac, home server, Private Cloud Compute, and external models are compute planes.

Reason: The iPhone is where identity, personal context, permissions, and approval live.

Consequence: Delegation requires Privacy Broker checks, minimization, audit logging, and user approval when data or actions are sensitive.

## ADR-0004: Codex works only from task files

Decision: Codex receives bounded tasks from `docs/CODEX_NEXT_TASK.md` and should create Draft PRs into `main`.

Reason: This keeps agent credits low, reduces scope drift, and preserves ChatGPT as strategy/review controller.

Consequence: ChatGPT must update the task file before giving a Codex prompt.
