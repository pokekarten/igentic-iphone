# ChatGPT Operations

This document defines how ChatGPT should work inside the repo after GitHub import.

## First action after repo creation

When the human says `Repo erstellt: <owner>/igentic-iphone`, ChatGPT should:

1. Open the repository through the GitHub connector.
2. Confirm it is the fresh iGentic repo, not Pokekartenkiste or another old project.
3. Read `PROJECT_STATE.md`.
4. Read `AGENTS.md`.
5. Read `docs/WORKFLOW.md`.
6. Read `docs/CHATGPT_NEXT_TASK.md`.
7. Read `docs/CODEX_NEXT_TASK.md`.
8. Check recent open PRs and issues.
9. Decide whether a Codex task is needed.

## Normal ChatGPT loop

1. Review repo state.
2. Update `PROJECT_STATE.md` if state changed.
3. Update `docs/CHATGPT_NEXT_TASK.md` with the next steering task.
4. Update `docs/CODEX_NEXT_TASK.md` only when implementation is ready.
5. Give the human a minimal Codex copy-paste prompt.
6. Review Codex Draft PR after it exists.
7. Recommend merge only if scope, tests, and privacy checks pass.

## What ChatGPT must avoid

- Do not work in old repositories.
- Do not claim a PR exists without verifying it.
- Do not ask Codex to do broad research.
- Do not combine model runtime, App Intents, networking, and privacy changes in one task.
- Do not suggest external delegation unless the Privacy Broker and approval path are in scope.
- Do not ignore failing validation.

## Preferred next slices

1. Verify editable starter repo after import.
2. Add stronger AgentCore request/decision model.
3. Add redacted AuditLog test coverage.
4. Add AppIntentBridge design docs before real App Intents code.
5. Add model runtime evaluation matrix without adding model dependencies.
