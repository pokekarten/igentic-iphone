# Roadmap

## Phase 0: Research & Architecture

- [x] Create initial repository structure.
- [x] Define privacy-first architecture.
- [x] Define data classes.
- [x] Identify Apple-native APIs and local runtime candidates.
- [ ] Create benchmark plan for iPhone Air.
- [ ] Create threat model for delegation.

## Phase 1: Local Agent Kernel

- [x] Add `TaskRouter` skeleton.
- [x] Add `PolicyEngine` skeleton.
- [x] Add `AuditLog` skeleton.
- [x] Add `DataClassification` model.
- [x] Add `ApprovalManager` skeleton.
- [ ] Add persistent local audit store.
- [ ] Add capability registry with permission metadata.

## Phase 2: Local Model Runtime

- [ ] Evaluate Apple Foundation Models where available.
- [ ] Evaluate Core AI / Core ML runtime path.
- [ ] Evaluate MLX Swift or MLC-LLM.
- [ ] Convert or load Qwen3-4B quantized candidate.
- [ ] Test router model candidate.
- [ ] Test embedding model candidate.

## Phase 3: App Intents

- [x] Add conceptual `AppIntentBridge` skeleton.
- [x] Add safe intent placeholders.
- [ ] Implement real `AppIntents` target in an iOS app project.
- [ ] Add Reminder integration.
- [ ] Add Calendar read/draft integration.
- [ ] Add Files read/search integration.
- [ ] Add approval UI before critical execution.

## Phase 4: Memory & Local RAG

- [x] Add in-memory `MemoryStore` skeleton.
- [ ] Add local vector index.
- [ ] Add encrypted persistence.
- [ ] Add deletion controls.
- [ ] Add memory scopes.
- [ ] Add auditability for retrieval.

## Phase 5: Trusted Device Delegation

- [x] Add `DelegationBroker` skeleton.
- [ ] Define Mac worker protocol.
- [ ] Define home server worker protocol.
- [ ] Evaluate MCP Swift SDK.
- [ ] Add Privacy Broker redaction pipeline.
- [ ] Add job queue and result verification.

## Phase 6: External AI optional

- [ ] Define external provider abstraction.
- [ ] Add outgoing context preview.
- [ ] Add redaction and minimization tests.
- [ ] Add explicit approval for provider calls.
- [ ] Add result verification before action.
