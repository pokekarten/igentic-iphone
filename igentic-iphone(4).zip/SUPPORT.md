# Support

## Getting help

Use GitHub Issues for actionable bugs, scoped feature requests, documentation gaps, and security-review placeholders.

Use GitHub Discussions, once enabled, for broader questions such as model candidates, architecture trade-offs, local runtime experiments, and community planning.

## Not supported

This project does not provide medical, legal, financial, identity, payment, or safety-critical advice. It is an experimental starter repository, not a production agent runtime.

## Good first questions

- Which local model/runtime should be evaluated next?
- Which App Intent is safe enough to prototype first?
- Which data class and approval rule applies to a proposed feature?
- How can a task remain offline-first?
