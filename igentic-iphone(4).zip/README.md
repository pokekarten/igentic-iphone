# iGentic iPhone

**Status:** Experimental / Research Prototype  
**Repository name:** `igentic-iphone`  
**Primary device assumption:** iPhone Air  
**Project type:** Privacy-first iPhone AI Runtime Layer / Personal AI Compute Layer

> The iPhone is not the strongest computer in a personal AI setup. It is the most trusted computer. It holds identity, context, permissions, approvals, private data and local policy. Larger compute can be delegated, but the iPhone remains the trust and control plane.

## Mission

iGentic iPhone explores a local, privacy-first AI runtime for iPhone. The goal is not to build another chatbot app. The goal is to define a small, auditable agent kernel that can understand tasks, classify data, choose local tools or models, request user approval for critical actions, and delegate heavier work only when policy allows it.

The project prioritizes:

- local-first inference and context handling
- offline-first operation as the default mode
- user approval before critical actions
- data minimization before delegation
- secure action surfaces instead of unsafe UI automation
- auditable behavior over unbounded autonomy

This repository is a **starter skeleton**, not a production app. It contains architecture docs, a Swift package skeleton, policy tests and GitHub workflow templates.

## Why iPhone Air

iPhone Air is a useful target because it combines strong local compute with the security model of iOS. It is thin and mobile, so it should not be treated as a long-running server. It is best used for short local inference, routing, privacy filtering, approval, secure local state and delegation to stronger trusted devices when needed.

Expected model posture:

- **1B class:** very comfortable for routing and lightweight local tasks.
- **3B class:** likely the practical sweet spot for useful local agent logic.
- **4B class:** realistic when quantized and used carefully.
- **7B/8B class:** possible in some runtimes, but likely warm, slower and unsuitable for long sessions.
- **larger models:** delegate to Mac, home server, Private Cloud Compute or explicit external AI.

## Core architecture

```text
User / Siri / Shortcut / Widget / App
        ↓
iPhone AI Layer Controller
        ↓
Intent Understanding
        ↓
Local Context Engine
        ↓
Task Router
        ↓
Local Execution or Controlled Delegation
        ↓
Action Layer via App Intents / Shortcuts / local APIs
        ↓
Audit Log / Approval / Result Verification
```

## Privacy-first principles

1. **Privacy before autonomy.** The agent must not gain new capability without policy and auditability.
2. **Local raw data by default.** Private source data stays on device unless a concrete policy allows a minimized derivative to leave.
3. **Data classification before tool execution.** Every request is assigned a data class before routing.
4. **Draft before send.** The default action pattern is preparing a draft, not executing irreversible actions.
5. **Approval before critical actions.** Sending messages, deleting files, changing appointments, external data sharing and purchases require confirmation.
6. **Delegation is controlled.** iPhone acts as the trust and control plane; Mac, home server or cloud are compute planes.
7. **Auditable by design.** Decisions, policies and tool calls are logged locally with redaction.

## Data classes

| Level | Name | Examples | Default behavior |
| --- | --- | --- | --- |
| 0 | Public | public docs, open web references | Local automatic use allowed |
| 1 | Low-risk app data | app settings, non-sensitive preferences | Local automatic use allowed |
| 2 | Personal task context | calendar, notes, files | Use only for a concrete task |
| 3 | Sensitive personal context | contacts, messages, location | Explicit approval required |
| 4 | Highly sensitive | health, finance, identity, keys | Never automatically delegate |

## Model strategy

The architecture is intentionally hybrid:

- **Apple Foundation Models**: native iPhone layer for Apple-integrated intelligence, Swift workflows, summaries, text understanding and App Intents / Siri-adjacent integration.
- **Core AI / Core ML**: on-device model execution and model integration layer for Apple silicon.
- **Qwen3-4B**: main candidate for a controllable local open agent brain, especially in quantized form.
- **Qwen3-1.7B or similar small model**: candidate for fast routing, intent detection and prefiltering.
- **Local embedding model**: local memory search, private RAG and document retrieval.
- **Mac / Home Server / PCC / External AI**: optional delegated compute only when local execution is not sufficient and policy allows it.

See [`MODEL_STRATEGY.md`](MODEL_STRATEGY.md) for model candidate notes.

## Operating modes

### Local Only

- no external model calls
- no telemetry
- local index and local logs
- model execution on device where possible
- critical actions still require approval

### Trusted Devices

- delegation only to owned devices such as Mac, iPad or home server
- encrypted local network connection
- raw data remains within the user's controlled devices where possible

### External AI

- per-task opt-in
- explicit preview of outgoing data
- redaction and minimization first
- audit log entry required
- highly sensitive data must not be delegated automatically

## Swift package

The current Swift package is under [`ios/`](ios/). It intentionally avoids hard dependencies on new or device-only frameworks so the core policy logic can be tested early.

```bash
cd ios
swift test
```

Current modules:

- `AgentCore`: policy, routing, data classes, audit, approval, model runtime and delegation skeletons.
- `AgentIntents`: safe bridge skeleton for future App Intents and Shortcuts integration.
- `AgentUI`: SwiftUI status and audit views when SwiftUI is available.



## Editable repo workflow

This repository is intended to be imported into a fresh GitHub repo and then developed through small, reviewable tasks.

Important steering files:

- [`AGENTS.md`](AGENTS.md) — rules for ChatGPT, Codex, and future coding agents.
- [`CONTRIBUTING.md`](CONTRIBUTING.md) — contribution and validation rules.
- [`docs/WORKFLOW.md`](docs/WORKFLOW.md) — ChatGPT + Codex operating loop.
- [`docs/CHATGPT_NEXT_TASK.md`](docs/CHATGPT_NEXT_TASK.md) — next steering task for ChatGPT.
- [`docs/CODEX_NEXT_TASK.md`](docs/CODEX_NEXT_TASK.md) — next bounded implementation task for Codex.
- [`docs/GITHUB_SETUP.md`](docs/GITHUB_SETUP.md) — how to import this ZIP into a fresh GitHub repository.

Recommended loop:

1. ChatGPT reviews repo state and updates `docs/CODEX_NEXT_TASK.md`.
2. Codex implements only that bounded task on `codex/<task-name>`.
3. Codex opens a draft PR.
4. ChatGPT reviews scope, diff, tests, and privacy impact.
5. Human merges only after the review is clean.



## Work with ChatGPT after GitHub import

This repository is intentionally prepared as a living working repo. After the ZIP is pushed to a fresh public GitHub repository, the expected operating loop is:

1. Human tells ChatGPT the real repo full name, for example `pokekarten/igentic-iphone`.
2. ChatGPT reads `PROJECT_STATE.md`, `AGENTS.md`, `docs/CHATGPT_NEXT_TASK.md`, `docs/CODEX_NEXT_TASK.md`, and recent GitHub issues/PRs.
3. ChatGPT updates `docs/CODEX_NEXT_TASK.md` before any Codex implementation task.
4. Codex receives only a narrow copy-paste prompt from `docs/CODEX_PROMPT_TEMPLATE.md` plus the active task file.
5. Codex creates a draft PR into `main`.
6. ChatGPT reviews the real PR diff, changed files, validation output, privacy impact, and scope before the human merges.

The repo must stay small-task driven: no broad rewrites, no model downloads, no secrets, no uncontrolled background agent, and no external data delegation without policy and approval.

## Roadmap

### Phase 0: Research & Architecture

- collect sources
- evaluate Apple-native APIs
- evaluate local LLM runtimes
- define data classes and privacy model

### Phase 1: Local Agent Kernel

- `TaskRouter`
- `PolicyEngine`
- `AuditLog`
- `DataClassification`
- `ApprovalManager`

### Phase 2: Local Model Runtime

- evaluate Apple Foundation Models
- evaluate Core AI
- evaluate MLX Swift or MLC-LLM
- test Qwen3-4B as main local candidate
- test an embedding model

### Phase 3: App Intents

- define secure actions
- calendar, reminders, notes, files
- draft before send
- approval before critical actions

### Phase 4: Memory & Local RAG

- local vector index
- encrypted storage
- deletion controls
- memory scopes
- auditability

### Phase 5: Trusted Device Delegation

- Mac worker
- home server worker
- MCP or custom protocol
- Privacy Broker
- job queue

### Phase 6: External AI optional

- Private Cloud Compute where available
- external models only with explicit approval
- data minimization
- redaction
- result verification

## Important limits

- iOS sandboxing restricts broad device access.
- Long-running background agents are not a realistic default on iPhone.
- Thermal and battery constraints matter for local LLM sessions.
- Many Apple Intelligence capabilities are region-, OS-, device- and API-dependent.
- External delegation creates privacy and compliance risk.
- App Store review and platform policy may restrict some automation patterns.

## Safety disclaimer

This project is not medical, legal or financial advice. It is an experimental architecture prototype. Security and privacy architecture must come before autonomy.

## License

Apache-2.0. See [`LICENSE`](LICENSE).


## Open Source Community

iGentic iPhone is intended to be public and open source from the first commit. The repository uses the Apache-2.0 license, keeps contribution rules in `CONTRIBUTING.md`, community expectations in `CODE_OF_CONDUCT.md`, security reporting in `SECURITY.md`, and governance notes in `GOVERNANCE.md`.

Good first contribution areas are documentation, threat modeling, Swift tests, App Intents skeletons, local model/runtime evaluation notes, and small privacy-policy improvements.

Recommended GitHub topics: `ios`, `swift`, `apple-intelligence`, `core-ml`, `app-intents`, `on-device-ai`, `local-first`, `privacy`, `ai-agents`, `llm`, `mlx`, `mcp`, `iphone`, `edge-ai`.

