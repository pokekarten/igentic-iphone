# Privacy Model

Privacy is the foundation of iGentic iPhone. Every feature must answer three questions before implementation:

1. What data class is required?
2. What operation is being performed?
3. Can the result be audited and revoked?

## Data classes

| Level | Name | Examples | Delegation policy |
| --- | --- | --- | --- |
| 0 | Public | public docs, open model metadata | Delegation allowed if useful |
| 1 | Low-risk app data | app state, non-sensitive preferences | Delegation allowed with minimization |
| 2 | Personal task context | calendar, notes, files | Delegation only with task-specific purpose |
| 3 | Sensitive personal context | contacts, messages, precise location | Explicit approval required |
| 4 | Highly sensitive | health, finance, identity, secrets, keys | No automatic external delegation |

## Operation classes

| Operation | Example | Default policy |
| --- | --- | --- |
| Read | read local note metadata | allowed if permission exists and data class permits |
| Prepare | draft a message, propose reminder | generally allowed locally |
| Execute | send, delete, move, purchase, share | approval required |
| Delegate | send derived context to a worker | depends on data class and operating mode |

## Minimization

Before delegation:

- remove identifiers not required for the task
- summarize raw data where possible
- replace names with labels when identity is irrelevant
- remove secrets, tokens and keys
- include only the smallest possible context window
- log what category of data was sent, not raw sensitive content

## Approval

User approval should include:

- the proposed action
- the data classes involved
- the destination if delegating
- whether raw data or minimized data leaves the device
- the expected result
- a clear approve / reject decision

## Audit log

Audit entries should record:

- timestamp
- intent
- operation
- data class
- policy decision
- approval status
- delegation target if any
- redacted summary

Audit logs must be local-first and deletable by the user.
