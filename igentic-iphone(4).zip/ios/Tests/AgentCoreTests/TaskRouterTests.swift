import XCTest
@testable import AgentCore

final class TaskRouterTests: XCTestCase {
    func testReminderInputRoutesToPrepareReminder() {
        let router = TaskRouter()
        let task = router.route(AgentRequest(input: "Erinnere mich morgen an den Termin"))
        XCTAssertEqual(task.intent, .createReminder)
        XCTAssertEqual(task.operation, .prepare)
        XCTAssertFalse(task.isCriticalAction)
    }

    func testDeleteInputIsCriticalExecution() {
        let router = TaskRouter()
        let task = router.route(AgentRequest(input: "Delete this file"))
        XCTAssertEqual(task.operation, .execute)
        XCTAssertTrue(task.isCriticalAction)
    }

    func testHeavyTaskSuggestsTrustedMacOutsideLocalOnly() {
        let router = TaskRouter()
        let task = router.route(AgentRequest(input: "Analyze a large codebase", operatingMode: .trustedDevices))
        XCTAssertEqual(task.intent, .delegateHeavyTask)
        XCTAssertEqual(task.suggestedTarget, .trustedMac)
    }
}
