import XCTest
@testable import AgentCore

final class DataClassificationTests: XCTestCase {
    func testOrderingReflectsSensitivity() {
        XCTAssertLessThan(DataClassification.publicData, .lowRiskAppData)
        XCTAssertLessThan(DataClassification.lowRiskAppData, .personalTaskContext)
        XCTAssertLessThan(DataClassification.personalTaskContext, .sensitivePersonalContext)
        XCTAssertLessThan(DataClassification.sensitivePersonalContext, .highlySensitive)
    }

    func testHighlySensitiveRequiresApprovalForDelegation() {
        XCTAssertTrue(DataClassification.highlySensitive.requiresExplicitApprovalForDelegation)
    }

    func testLowRiskAllowsAutomaticExternalDelegationFlag() {
        XCTAssertTrue(DataClassification.lowRiskAppData.allowsAutomaticExternalDelegation)
        XCTAssertFalse(DataClassification.sensitivePersonalContext.allowsAutomaticExternalDelegation)
    }
}
