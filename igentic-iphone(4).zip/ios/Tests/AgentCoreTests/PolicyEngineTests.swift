import XCTest
@testable import AgentCore

final class PolicyEngineTests: XCTestCase {
    func testLocalReadLowRiskDataIsAllowed() {
        let engine = PolicyEngine(policy: .localOnly)
        let decision = engine.evaluate(
            PolicyEvaluationRequest(operation: .read, dataClassification: .lowRiskAppData)
        )
        XCTAssertEqual(decision.kind, .allow)
    }

    func testCriticalActionRequiresApproval() {
        let engine = PolicyEngine(policy: .localOnly)
        let decision = engine.evaluate(
            PolicyEvaluationRequest(
                operation: .execute,
                dataClassification: .personalTaskContext,
                target: .localDevice,
                isCriticalAction: true
            )
        )
        XCTAssertEqual(decision.kind, .requireApproval)
    }

    func testExternalDelegationDeniedInLocalOnlyMode() {
        let engine = PolicyEngine(policy: .localOnly)
        let decision = engine.evaluate(
            PolicyEvaluationRequest(
                operation: .delegate,
                dataClassification: .lowRiskAppData,
                target: .externalAI
            )
        )
        XCTAssertEqual(decision.kind, .deny)
    }

    func testHighlySensitiveDataDeniedForExternalDelegation() {
        let engine = PolicyEngine(policy: .externalAI)
        let decision = engine.evaluate(
            PolicyEvaluationRequest(
                operation: .delegate,
                dataClassification: .highlySensitive,
                target: .externalAI
            )
        )
        XCTAssertEqual(decision.kind, .deny)
    }
}
