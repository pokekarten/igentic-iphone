#if canImport(SwiftUI)
import SwiftUI
import AgentCore

public struct AuditLogView: View {
    public let entries: [AuditLogEntry]

    public init(entries: [AuditLogEntry]) {
        self.entries = entries
    }

    public var body: some View {
        List(entries) { entry in
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.intent.rawValue)
                    .font(.headline)
                Text("Decision: \(entry.decision.rawValue)")
                Text("Data: \(entry.dataClassification.label)")
                    .font(.caption)
                Text(entry.summary)
                    .font(.caption2)
            }
        }
    }
}
#endif
