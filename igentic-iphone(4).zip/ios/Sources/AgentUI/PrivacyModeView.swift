#if canImport(SwiftUI)
import SwiftUI
import AgentCore

public struct PrivacyModeView: View {
    public let modes: [OperatingMode] = OperatingMode.allCases

    public init() {}

    public var body: some View {
        List(modes, id: \.rawValue) { mode in
            VStack(alignment: .leading) {
                Text(mode.rawValue)
                    .font(.headline)
                Text(description(for: mode))
                    .font(.caption)
            }
        }
    }

    private func description(for mode: OperatingMode) -> String {
        switch mode {
        case .localOnly:
            return "No external model calls. Local index and logs only."
        case .trustedDevices:
            return "Delegation only to owned devices."
        case .externalAI:
            return "External AI per task with minimization and approval."
        }
    }
}
#endif
