#if canImport(SwiftUI)
import SwiftUI
import AgentCore

public struct AgentStatusView: View {
    public let mode: OperatingMode
    public let lastDecision: PolicyDecisionKind?

    public init(mode: OperatingMode, lastDecision: PolicyDecisionKind? = nil) {
        self.mode = mode
        self.lastDecision = lastDecision
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("iGentic iPhone")
                .font(.headline)
            Text("Mode: \(mode.rawValue)")
            if let lastDecision {
                Text("Last policy decision: \(lastDecision.rawValue)")
            }
        }
        .padding()
    }
}
#endif
