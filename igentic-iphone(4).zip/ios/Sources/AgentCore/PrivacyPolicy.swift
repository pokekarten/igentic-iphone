import Foundation

public enum PolicyDecisionKind: String, Codable, Sendable, Equatable {
    case allow
    case requireApproval
    case deny
}

public struct PolicyDecision: Codable, Sendable, Equatable {
    public let kind: PolicyDecisionKind
    public let reason: String
    public let requiresAudit: Bool

    public init(kind: PolicyDecisionKind, reason: String, requiresAudit: Bool = true) {
        self.kind = kind
        self.reason = reason
        self.requiresAudit = requiresAudit
    }

    public static func allow(_ reason: String) -> PolicyDecision {
        PolicyDecision(kind: .allow, reason: reason)
    }

    public static func requireApproval(_ reason: String) -> PolicyDecision {
        PolicyDecision(kind: .requireApproval, reason: reason)
    }

    public static func deny(_ reason: String) -> PolicyDecision {
        PolicyDecision(kind: .deny, reason: reason)
    }
}

public struct PrivacyPolicy: Codable, Sendable, Equatable {
    public var operatingMode: OperatingMode
    public var allowExternalAI: Bool
    public var allowTrustedDeviceDelegation: Bool
    public var requireApprovalForCriticalActions: Bool

    public init(
        operatingMode: OperatingMode = .localOnly,
        allowExternalAI: Bool = false,
        allowTrustedDeviceDelegation: Bool = false,
        requireApprovalForCriticalActions: Bool = true
    ) {
        self.operatingMode = operatingMode
        self.allowExternalAI = allowExternalAI
        self.allowTrustedDeviceDelegation = allowTrustedDeviceDelegation
        self.requireApprovalForCriticalActions = requireApprovalForCriticalActions
    }

    public static let localOnly = PrivacyPolicy()

    public static let trustedDevices = PrivacyPolicy(
        operatingMode: .trustedDevices,
        allowExternalAI: false,
        allowTrustedDeviceDelegation: true,
        requireApprovalForCriticalActions: true
    )

    public static let externalAI = PrivacyPolicy(
        operatingMode: .externalAI,
        allowExternalAI: true,
        allowTrustedDeviceDelegation: true,
        requireApprovalForCriticalActions: true
    )
}
