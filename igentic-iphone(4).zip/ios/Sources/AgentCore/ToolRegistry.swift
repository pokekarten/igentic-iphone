import Foundation

public struct ToolDescriptor: Codable, Sendable, Equatable, Identifiable {
    public let id: String
    public let name: String
    public let operation: OperationKind
    public let maximumDataClass: DataClassification
    public let requiresApproval: Bool

    public init(
        id: String,
        name: String,
        operation: OperationKind,
        maximumDataClass: DataClassification,
        requiresApproval: Bool
    ) {
        self.id = id
        self.name = name
        self.operation = operation
        self.maximumDataClass = maximumDataClass
        self.requiresApproval = requiresApproval
    }
}

public final class ToolRegistry: @unchecked Sendable {
    private var tools: [String: ToolDescriptor]

    public init(tools: [ToolDescriptor] = ToolRegistry.defaultTools) {
        self.tools = Dictionary(uniqueKeysWithValues: tools.map { ($0.id, $0) })
    }

    public func register(_ tool: ToolDescriptor) {
        tools[tool.id] = tool
    }

    public func tool(id: String) -> ToolDescriptor? {
        tools[id]
    }

    public func allTools() -> [ToolDescriptor] {
        tools.values.sorted { $0.id < $1.id }
    }

    public static let defaultTools: [ToolDescriptor] = [
        ToolDescriptor(id: "readCalendar", name: "Read Calendar", operation: .read, maximumDataClass: .personalTaskContext, requiresApproval: false),
        ToolDescriptor(id: "createReminder", name: "Create Reminder Draft", operation: .prepare, maximumDataClass: .personalTaskContext, requiresApproval: false),
        ToolDescriptor(id: "draftMessage", name: "Draft Message", operation: .prepare, maximumDataClass: .sensitivePersonalContext, requiresApproval: false),
        ToolDescriptor(id: "sendMessage", name: "Send Message", operation: .execute, maximumDataClass: .sensitivePersonalContext, requiresApproval: true),
        ToolDescriptor(id: "findFile", name: "Find File", operation: .read, maximumDataClass: .personalTaskContext, requiresApproval: false),
        ToolDescriptor(id: "delegateToMac", name: "Delegate to Mac", operation: .delegate, maximumDataClass: .personalTaskContext, requiresApproval: false),
        ToolDescriptor(id: "requestApproval", name: "Request Approval", operation: .prepare, maximumDataClass: .highlySensitive, requiresApproval: false)
    ]
}
