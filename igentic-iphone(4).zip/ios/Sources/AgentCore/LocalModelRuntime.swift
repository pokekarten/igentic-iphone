import Foundation

public enum LocalModelRole: String, Codable, Sendable, Equatable {
    case nativeAppleLayer
    case localAgentBrain
    case router
    case embedding
}

public struct LocalModelRequest: Sendable, Equatable {
    public let prompt: String
    public let role: LocalModelRole
    public let dataClassification: DataClassification

    public init(prompt: String, role: LocalModelRole, dataClassification: DataClassification) {
        self.prompt = prompt
        self.role = role
        self.dataClassification = dataClassification
    }
}

public struct LocalModelResponse: Sendable, Equatable {
    public let text: String
    public let modelIdentifier: String
    public let executedLocally: Bool

    public init(text: String, modelIdentifier: String, executedLocally: Bool) {
        self.text = text
        self.modelIdentifier = modelIdentifier
        self.executedLocally = executedLocally
    }
}

public protocol LocalModelRunning: Sendable {
    func run(_ request: LocalModelRequest) async throws -> LocalModelResponse
}

public final class LocalModelRuntime: LocalModelRunning {
    public init() {}

    public func run(_ request: LocalModelRequest) async throws -> LocalModelResponse {
        // Placeholder runtime: replace with Foundation Models, Core AI, MLX, MLC-LLM, or llama.cpp adapter.
        let prefix: String
        switch request.role {
        case .nativeAppleLayer: prefix = "Apple-native placeholder"
        case .localAgentBrain: prefix = "Local agent brain placeholder"
        case .router: prefix = "Router placeholder"
        case .embedding: prefix = "Embedding placeholder"
        }

        return LocalModelResponse(
            text: "\(prefix): prepared local response for data class \(request.dataClassification.rawValue).",
            modelIdentifier: "stub-local-runtime",
            executedLocally: true
        )
    }
}
