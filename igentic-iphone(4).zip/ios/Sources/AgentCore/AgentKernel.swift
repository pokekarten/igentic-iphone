import Foundation

public struct AgentKernelResponse: Sendable, Equatable {
    public let routedTask: RoutedTask
    public let decision: PolicyDecision
    public let approvalStatus: ApprovalStatus
    public let responseText: String

    public init(routedTask: RoutedTask, decision: PolicyDecision, approvalStatus: ApprovalStatus, responseText: String) {
        self.routedTask = routedTask
        self.decision = decision
        self.approvalStatus = approvalStatus
        self.responseText = responseText
    }
}

public final class AgentKernel: Sendable {
    private let router: TaskRouter
    private let policyEngine: PolicyEngine
    private let modelRuntime: any LocalModelRunning
    private let delegationBroker: any DelegationHandling
    private let approvalManager: any ApprovalManaging
    private let auditLog: AuditLog

    public init(
        router: TaskRouter = TaskRouter(),
        policyEngine: PolicyEngine = PolicyEngine(),
        modelRuntime: any LocalModelRunning = LocalModelRuntime(),
        delegationBroker: any DelegationHandling = DelegationBroker(),
        approvalManager: any ApprovalManaging = ApprovalManager(),
        auditLog: AuditLog = AuditLog()
    ) {
        self.router = router
        self.policyEngine = policyEngine
        self.modelRuntime = modelRuntime
        self.delegationBroker = delegationBroker
        self.approvalManager = approvalManager
        self.auditLog = auditLog
    }

    public func handle(_ request: AgentRequest) async throws -> AgentKernelResponse {
        let routed = router.route(request)
        let evaluation = PolicyEvaluationRequest(
            operation: routed.operation,
            dataClassification: routed.dataClassification,
            target: routed.suggestedTarget,
            isCriticalAction: routed.isCriticalAction
        )
        let decision = policyEngine.evaluate(evaluation)

        let approvalStatus: ApprovalStatus
        if decision.kind == .requireApproval {
            approvalStatus = await approvalManager.requestApproval(
                ApprovalRequest(
                    reason: decision.reason,
                    dataClassification: routed.dataClassification,
                    operation: routed.operation,
                    target: routed.suggestedTarget
                )
            )
        } else {
            approvalStatus = .notRequired
        }

        let responseText: String
        if decision.kind == .deny {
            responseText = "Denied by policy: \(decision.reason)"
        } else if routed.operation == .delegate && routed.suggestedTarget != .localDevice {
            let result = try await delegationBroker.delegate(
                DelegationJob(
                    inputSummary: request.input,
                    dataClassification: routed.dataClassification,
                    preferredTarget: routed.suggestedTarget
                )
            )
            responseText = result.resultSummary
        } else {
            let modelResponse = try await modelRuntime.run(
                LocalModelRequest(
                    prompt: request.input,
                    role: routed.intent == .delegateHeavyTask ? .localAgentBrain : .router,
                    dataClassification: routed.dataClassification
                )
            )
            responseText = modelResponse.text
        }

        auditLog.append(
            AuditLogEntry(
                intent: routed.intent,
                operation: routed.operation,
                dataClassification: routed.dataClassification,
                decision: decision.kind,
                target: routed.suggestedTarget,
                summary: decision.reason
            )
        )

        return AgentKernelResponse(
            routedTask: routed,
            decision: decision,
            approvalStatus: approvalStatus,
            responseText: responseText
        )
    }

    public func auditEntries() -> [AuditLogEntry] {
        auditLog.allEntries()
    }
}
