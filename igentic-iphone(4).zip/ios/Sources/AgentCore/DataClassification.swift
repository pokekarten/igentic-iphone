import Foundation

public enum DataClassification: Int, Codable, Sendable, Comparable, CaseIterable {
    case publicData = 0
    case lowRiskAppData = 1
    case personalTaskContext = 2
    case sensitivePersonalContext = 3
    case highlySensitive = 4

    public static func < (lhs: DataClassification, rhs: DataClassification) -> Bool {
        lhs.rawValue < rhs.rawValue
    }

    public var label: String {
        switch self {
        case .publicData: return "Level 0: Public"
        case .lowRiskAppData: return "Level 1: Low-risk app data"
        case .personalTaskContext: return "Level 2: Personal task context"
        case .sensitivePersonalContext: return "Level 3: Sensitive personal context"
        case .highlySensitive: return "Level 4: Highly sensitive"
        }
    }

    public var requiresExplicitApprovalForDelegation: Bool {
        self >= .sensitivePersonalContext
    }

    public var allowsAutomaticExternalDelegation: Bool {
        self <= .lowRiskAppData
    }
}

public enum OperationKind: String, Codable, Sendable, CaseIterable {
    case read
    case prepare
    case execute
    case delegate
}

public enum OperatingMode: String, Codable, Sendable, CaseIterable {
    case localOnly
    case trustedDevices
    case externalAI
}

public enum DelegationTarget: String, Codable, Sendable, CaseIterable {
    case none
    case localDevice
    case trustedMac
    case trustedHomeServer
    case privateCloudCompute
    case externalAI

    public var isExternal: Bool {
        switch self {
        case .privateCloudCompute, .externalAI:
            return true
        default:
            return false
        }
    }
}
