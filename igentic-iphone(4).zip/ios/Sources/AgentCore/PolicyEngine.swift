import Foundation

public struct PolicyEvaluationRequest: Sendable, Equatable {
    public let operation: OperationKind
    public let dataClassification: DataClassification
    public let target: DelegationTarget
    public let isCriticalAction: Bool

    public init(
        operation: OperationKind,
        dataClassification: DataClassification,
        target: DelegationTarget = .none,
        isCriticalAction: Bool = false
    ) {
        self.operation = operation
        self.dataClassification = dataClassification
        self.target = target
        self.isCriticalAction = isCriticalAction
    }
}

public final class PolicyEngine: Sendable {
    public let policy: PrivacyPolicy

    public init(policy: PrivacyPolicy = .localOnly) {
        self.policy = policy
    }

    public func evaluate(_ request: PolicyEvaluationRequest) -> PolicyDecision {
        if request.dataClassification == .highlySensitive && request.target.isExternal {
            return .deny("Level 4 data must not be automatically delegated externally.")
        }

        if request.isCriticalAction && policy.requireApprovalForCriticalActions {
            return .requireApproval("Critical actions require explicit user approval.")
        }

        switch request.operation {
        case .read:
            if request.dataClassification >= .sensitivePersonalContext {
                return .requireApproval("Reading sensitive personal context requires approval.")
            }
            return .allow("Local read is allowed by policy.")

        case .prepare:
            if request.dataClassification == .highlySensitive {
                return .requireApproval("Preparing actions with Level 4 data requires approval.")
            }
            return .allow("Preparing a draft is allowed locally.")

        case .execute:
            return .requireApproval("Execution requires approval by default.")

        case .delegate:
            return evaluateDelegation(request)
        }
    }

    private func evaluateDelegation(_ request: PolicyEvaluationRequest) -> PolicyDecision {
        if request.target == .none || request.target == .localDevice {
            return .allow("Local execution is not external delegation.")
        }

        if request.target == .trustedMac || request.target == .trustedHomeServer {
            guard policy.allowTrustedDeviceDelegation else {
                return .deny("Trusted device delegation is disabled in current mode.")
            }
            if request.dataClassification.requiresExplicitApprovalForDelegation {
                return .requireApproval("Sensitive context requires approval before trusted-device delegation.")
            }
            return .allow("Trusted device delegation is allowed with minimization.")
        }

        if request.target.isExternal {
            guard policy.allowExternalAI else {
                return .deny("External AI delegation is disabled in current mode.")
            }
            if request.dataClassification >= .sensitivePersonalContext {
                return .requireApproval("Sensitive context requires explicit approval before external AI delegation.")
            }
            return .allow("External delegation is allowed for low-risk data with minimization.")
        }

        return .deny("Unsupported delegation target.")
    }
}
