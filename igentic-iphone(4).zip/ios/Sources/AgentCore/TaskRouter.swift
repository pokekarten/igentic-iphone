import Foundation

public enum TaskIntent: String, Codable, Sendable, Equatable {
    case summarize
    case findFile
    case createReminder
    case draftMessage
    case searchMemory
    case delegateHeavyTask
    case unknown
}

public struct AgentRequest: Sendable, Equatable {
    public let input: String
    public let operatingMode: OperatingMode
    public let declaredDataClassification: DataClassification?

    public init(
        input: String,
        operatingMode: OperatingMode = .localOnly,
        declaredDataClassification: DataClassification? = nil
    ) {
        self.input = input
        self.operatingMode = operatingMode
        self.declaredDataClassification = declaredDataClassification
    }
}

public struct RoutedTask: Sendable, Equatable {
    public let intent: TaskIntent
    public let operation: OperationKind
    public let suggestedTarget: DelegationTarget
    public let dataClassification: DataClassification
    public let isCriticalAction: Bool

    public init(
        intent: TaskIntent,
        operation: OperationKind,
        suggestedTarget: DelegationTarget,
        dataClassification: DataClassification,
        isCriticalAction: Bool
    ) {
        self.intent = intent
        self.operation = operation
        self.suggestedTarget = suggestedTarget
        self.dataClassification = dataClassification
        self.isCriticalAction = isCriticalAction
    }
}

public final class TaskRouter: Sendable {
    public init() {}

    public func route(_ request: AgentRequest) -> RoutedTask {
        let normalized = request.input.lowercased()
        let classification = request.declaredDataClassification ?? inferDataClass(from: normalized)

        if normalized.contains("delete") || normalized.contains("send") || normalized.contains("verschick") || normalized.contains("lösche") {
            return RoutedTask(
                intent: .draftMessage,
                operation: .execute,
                suggestedTarget: .localDevice,
                dataClassification: classification,
                isCriticalAction: true
            )
        }

        if normalized.contains("reminder") || normalized.contains("erinner") {
            return RoutedTask(
                intent: .createReminder,
                operation: .prepare,
                suggestedTarget: .localDevice,
                dataClassification: classification,
                isCriticalAction: false
            )
        }

        if normalized.contains("file") || normalized.contains("datei") || normalized.contains("find") || normalized.contains("suche") {
            return RoutedTask(
                intent: .findFile,
                operation: .read,
                suggestedTarget: .localDevice,
                dataClassification: classification,
                isCriticalAction: false
            )
        }

        if normalized.contains("large") || normalized.contains("codebase") || normalized.contains("video") || normalized.contains("lange") {
            return RoutedTask(
                intent: .delegateHeavyTask,
                operation: .delegate,
                suggestedTarget: request.operatingMode == .localOnly ? .localDevice : .trustedMac,
                dataClassification: classification,
                isCriticalAction: false
            )
        }

        if normalized.contains("memory") || normalized.contains("gedächtnis") {
            return RoutedTask(
                intent: .searchMemory,
                operation: .read,
                suggestedTarget: .localDevice,
                dataClassification: classification,
                isCriticalAction: false
            )
        }

        return RoutedTask(
            intent: .summarize,
            operation: .prepare,
            suggestedTarget: .localDevice,
            dataClassification: classification,
            isCriticalAction: false
        )
    }

    private func inferDataClass(from normalizedInput: String) -> DataClassification {
        if normalizedInput.contains("health") || normalizedInput.contains("finance") || normalizedInput.contains("key") || normalizedInput.contains("gesund") || normalizedInput.contains("konto") {
            return .highlySensitive
        }
        if normalizedInput.contains("contact") || normalizedInput.contains("message") || normalizedInput.contains("location") || normalizedInput.contains("kontakt") || normalizedInput.contains("nachricht") || normalizedInput.contains("standort") {
            return .sensitivePersonalContext
        }
        if normalizedInput.contains("calendar") || normalizedInput.contains("note") || normalizedInput.contains("file") || normalizedInput.contains("kalender") || normalizedInput.contains("notiz") || normalizedInput.contains("datei") {
            return .personalTaskContext
        }
        return .lowRiskAppData
    }
}
