import Foundation

public enum ApprovalStatus: String, Codable, Sendable, Equatable {
    case notRequired
    case pending
    case approved
    case rejected
}

public struct ApprovalRequest: Sendable, Equatable, Identifiable {
    public let id: UUID
    public let reason: String
    public let dataClassification: DataClassification
    public let operation: OperationKind
    public let target: DelegationTarget

    public init(
        id: UUID = UUID(),
        reason: String,
        dataClassification: DataClassification,
        operation: OperationKind,
        target: DelegationTarget
    ) {
        self.id = id
        self.reason = reason
        self.dataClassification = dataClassification
        self.operation = operation
        self.target = target
    }
}

public protocol ApprovalManaging: Sendable {
    func requestApproval(_ request: ApprovalRequest) async -> ApprovalStatus
}

public final class ApprovalManager: ApprovalManaging {
    private let defaultDecision: ApprovalStatus

    public init(defaultDecision: ApprovalStatus = .pending) {
        self.defaultDecision = defaultDecision
    }

    public func requestApproval(_ request: ApprovalRequest) async -> ApprovalStatus {
        // Real implementation must present a user-facing approval UI.
        defaultDecision
    }
}
