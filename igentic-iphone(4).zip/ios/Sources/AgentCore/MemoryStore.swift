import Foundation

public struct MemoryRecord: Codable, Sendable, Equatable, Identifiable {
    public let id: UUID
    public let scope: String
    public let text: String
    public let dataClassification: DataClassification
    public let createdAt: Date

    public init(
        id: UUID = UUID(),
        scope: String,
        text: String,
        dataClassification: DataClassification,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.scope = scope
        self.text = text
        self.dataClassification = dataClassification
        self.createdAt = createdAt
    }
}

public final class MemoryStore: @unchecked Sendable {
    private var records: [MemoryRecord] = []

    public init() {}

    public func add(_ record: MemoryRecord) {
        records.append(record)
    }

    public func search(query: String, maximumDataClass: DataClassification = .personalTaskContext) -> [MemoryRecord] {
        let normalized = query.lowercased()
        return records.filter { record in
            record.dataClassification <= maximumDataClass && record.text.lowercased().contains(normalized)
        }
    }

    public func delete(id: UUID) {
        records.removeAll { $0.id == id }
    }

    public func deleteAll() {
        records.removeAll()
    }
}
