import Foundation

public struct AuditLogEntry: Codable, Sendable, Equatable, Identifiable {
    public let id: UUID
    public let timestamp: Date
    public let intent: TaskIntent
    public let operation: OperationKind
    public let dataClassification: DataClassification
    public let decision: PolicyDecisionKind
    public let target: DelegationTarget
    public let summary: String

    public init(
        id: UUID = UUID(),
        timestamp: Date = Date(),
        intent: TaskIntent,
        operation: OperationKind,
        dataClassification: DataClassification,
        decision: PolicyDecisionKind,
        target: DelegationTarget,
        summary: String
    ) {
        self.id = id
        self.timestamp = timestamp
        self.intent = intent
        self.operation = operation
        self.dataClassification = dataClassification
        self.decision = decision
        self.target = target
        self.summary = summary
    }
}

public final class AuditLog: @unchecked Sendable {
    private var entries: [AuditLogEntry] = []

    public init() {}

    public func append(_ entry: AuditLogEntry) {
        entries.append(entry)
    }

    public func allEntries() -> [AuditLogEntry] {
        entries
    }

    public func removeAll() {
        entries.removeAll()
    }
}
