import Foundation
import AgentCore

public struct RequestApprovalIntentViewModel: Sendable, Equatable {
    public let title: String
    public let explanation: String
    public let dataClassification: DataClassification
    public let operation: OperationKind
    public let target: DelegationTarget

    public init(
        title: String,
        explanation: String,
        dataClassification: DataClassification,
        operation: OperationKind,
        target: DelegationTarget
    ) {
        self.title = title
        self.explanation = explanation
        self.dataClassification = dataClassification
        self.operation = operation
        self.target = target
    }
}

public enum RequestApprovalIntent {
    public static func buildViewModel(from request: ApprovalRequest) -> RequestApprovalIntentViewModel {
        RequestApprovalIntentViewModel(
            title: "Approval required",
            explanation: request.reason,
            dataClassification: request.dataClassification,
            operation: request.operation,
            target: request.target
        )
    }
}
