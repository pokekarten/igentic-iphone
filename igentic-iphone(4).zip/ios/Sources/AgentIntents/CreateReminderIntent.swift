import Foundation
import AgentCore

public struct CreateReminderIntentDraft: Sendable, Equatable {
    public let title: String
    public let notes: String?
    public let dueDate: Date?
    public let dataClassification: DataClassification

    public init(title: String, notes: String? = nil, dueDate: Date? = nil, dataClassification: DataClassification = .personalTaskContext) {
        self.title = title
        self.notes = notes
        self.dueDate = dueDate
        self.dataClassification = dataClassification
    }
}

public enum CreateReminderIntent {
    public static func prepare(_ draft: CreateReminderIntentDraft) -> String {
        // Future implementation should map this to AppIntents or EventKit/Reminders integration.
        "Prepared reminder draft: \(draft.title)"
    }
}
