import Foundation
import AgentCore

public struct FindFileIntentRequest: Sendable, Equatable {
    public let query: String
    public let dataClassification: DataClassification

    public init(query: String, dataClassification: DataClassification = .personalTaskContext) {
        self.query = query
        self.dataClassification = dataClassification
    }
}

public enum FindFileIntent {
    public static func prepare(_ request: FindFileIntentRequest) -> String {
        // Future implementation should use Files/document picker APIs with explicit permissions.
        "Prepared local file search for: \(request.query)"
    }
}
