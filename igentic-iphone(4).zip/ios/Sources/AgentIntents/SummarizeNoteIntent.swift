import Foundation
import AgentCore

public struct SummarizeNoteIntentRequest: Sendable, Equatable {
    public let noteSummary: String
    public let dataClassification: DataClassification

    public init(noteSummary: String, dataClassification: DataClassification = .personalTaskContext) {
        self.noteSummary = noteSummary
        self.dataClassification = dataClassification
    }
}

public enum SummarizeNoteIntent {
    public static func prepare(_ request: SummarizeNoteIntentRequest) -> String {
        // Future implementation should use a local model runtime, not send raw note contents externally.
        "Prepared local note summary request."
    }
}
