import Foundation
import AgentCore

public struct AppIntentActionRequest: Sendable, Equatable {
    public let toolID: String
    public let payloadSummary: String
    public let dataClassification: DataClassification
    public let operation: OperationKind

    public init(toolID: String, payloadSummary: String, dataClassification: DataClassification, operation: OperationKind) {
        self.toolID = toolID
        self.payloadSummary = payloadSummary
        self.dataClassification = dataClassification
        self.operation = operation
    }
}

public struct AppIntentActionResult: Sendable, Equatable {
    public let preparedOnly: Bool
    public let summary: String

    public init(preparedOnly: Bool, summary: String) {
        self.preparedOnly = preparedOnly
        self.summary = summary
    }
}

public final class AppIntentBridge: Sendable {
    private let policyEngine: PolicyEngine

    public init(policyEngine: PolicyEngine = PolicyEngine()) {
        self.policyEngine = policyEngine
    }

    public func prepareAction(_ request: AppIntentActionRequest) -> AppIntentActionResult {
        let decision = policyEngine.evaluate(
            PolicyEvaluationRequest(
                operation: request.operation,
                dataClassification: request.dataClassification,
                target: .localDevice,
                isCriticalAction: request.operation == .execute
            )
        )

        switch decision.kind {
        case .allow:
            return AppIntentActionResult(preparedOnly: true, summary: "Prepared action for \(request.toolID).")
        case .requireApproval:
            return AppIntentActionResult(preparedOnly: true, summary: "Approval required before executing \(request.toolID).")
        case .deny:
            return AppIntentActionResult(preparedOnly: true, summary: "Denied by policy: \(decision.reason)")
        }
    }
}
