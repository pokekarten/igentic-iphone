// swift-tools-version: 5.9

import PackageDescription

let package = Package(
    name: "iGenticPhone",
    platforms: [
        .iOS(.v17),
        .macOS(.v14)
    ],
    products: [
        .library(name: "AgentCore", targets: ["AgentCore"]),
        .library(name: "AgentIntents", targets: ["AgentIntents"]),
        .library(name: "AgentUI", targets: ["AgentUI"])
    ],
    targets: [
        .target(name: "AgentCore", path: "Sources/AgentCore"),
        .target(name: "AgentIntents", dependencies: ["AgentCore"], path: "Sources/AgentIntents"),
        .target(name: "AgentUI", dependencies: ["AgentCore"], path: "Sources/AgentUI"),
        .testTarget(name: "AgentCoreTests", dependencies: ["AgentCore"], path: "Tests/AgentCoreTests")
    ]
)
