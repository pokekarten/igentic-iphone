# Governance

## Project model

iGentic iPhone starts as a maintainer-led open-source research prototype. The goal is to build a small, high-signal community around privacy-first on-device AI, iOS agent architecture, and secure delegation.

## Decision priorities

1. Privacy and safety before autonomy.
2. Local-first behavior before external delegation.
3. Small, reviewable PRs before large rewrites.
4. Clear architecture documents before implementation-heavy changes.
5. User approval for critical actions before automation convenience.

## Maintainer responsibilities

Maintainers should:

- keep the roadmap realistic
- label issues clearly
- review PR scope before implementation detail
- reject changes that bypass policy, approval, or audit requirements
- keep the repository welcoming for docs, design, research, testing, and code contributors

## Contribution path

New contributors should start with documentation, tests, model/runtime evaluation notes, issue triage, or small Swift skeleton improvements. Major runtime, security, or delegation changes should begin as a design issue or discussion before code.

## AI-assisted contributions

AI-generated contributions are welcome when they are reviewed by a human contributor, scoped clearly, and validated with repository checks. Pull requests should disclose material AI assistance in the PR checklist when relevant.
